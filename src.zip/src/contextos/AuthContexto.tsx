/**
 * ========================================
 * CONTEXTO AUTH — Autenticação com persistência
 * ========================================
 * Sessão persistida via localStorage.
 * Inclui tipo_comprador para segmentação de preços.
 */

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Utilizador, TipoComprador } from '@/tipos';

const STORAGE_KEY = 'angrolink_auth_user';

const UTILIZADORES_MOCK: Record<string, Utilizador> = {
  'admin@angrolink.ao': {
    id: 'u-admin',
    nome: 'Administrador',
    email: 'admin@angrolink.ao',
    telefone: '244900000000',
    provincia: 'Luanda',
    municipio: 'Belas',
    papel: 'admin',
  },
  'vendedor@angrolink.ao': {
    id: 'u-v1',
    nome: 'Maria Josefa',
    email: 'vendedor@angrolink.ao',
    telefone: '244923456789',
    provincia: 'Luanda',
    municipio: 'Viana',
    papel: 'vendedor',
    vendedor_id: '544fb537-1486-4407-a843-1c38ddfdc96f',
  },
  'cliente@angrolink.ao': {
    id: 'u-c1',
    nome: 'Paulo Santos',
    email: 'cliente@angrolink.ao',
    telefone: '244911111111',
    provincia: 'Luanda',
    municipio: 'Belas',
    papel: 'cliente',
    tipo_comprador: 'casa',
  },
  'negocio@angrolink.ao': {
    id: 'u-c2',
    nome: 'Empresa Distribuidora ABC',
    email: 'negocio@angrolink.ao',
    telefone: '244922222222',
    provincia: 'Luanda',
    municipio: 'Viana',
    papel: 'cliente',
    tipo_comprador: 'negocio',
  },
};

interface AuthContextoTipo {
  utilizador: Utilizador | null;
  login: (email: string, senha: string) => Promise<boolean>;
  logout: () => void;
  autenticado: boolean;
  pronto: boolean;
  tipoComprador: TipoComprador;
  atualizarTipoComprador: (tipo: TipoComprador) => void;
}

const AuthContexto = createContext<AuthContextoTipo | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [utilizador, setUtilizador] = useState<Utilizador | null>(null);
  const [pronto, setPronto] = useState(false);

  const tipoComprador: TipoComprador = utilizador?.tipo_comprador || 'casa';

  const atualizarTipoComprador = (tipo: TipoComprador) => {
    if (!utilizador) return;

    const atualizado = { ...utilizador, tipo_comprador: tipo };
    setUtilizador(atualizado);

    // 🔥 persistência imediata (evita inconsistências)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(atualizado));
  };

  useEffect(() => {
    try {
      const guardado = localStorage.getItem(STORAGE_KEY);

      if (guardado) {
        const parsed = JSON.parse(guardado);

        // 🔥 validação mínima
        if (parsed && parsed.id && parsed.email) {
          setUtilizador(parsed);
        } else {
          localStorage.removeItem(STORAGE_KEY);
        }
      }
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    }

    setPronto(true);
  }, []);

  useEffect(() => {
    if (!pronto) return;

    if (utilizador) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(utilizador));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [utilizador, pronto]);

  const login = async (email: string, _senha: string): Promise<boolean> => {
    const user = UTILIZADORES_MOCK[email.toLowerCase()];

    if (user) {
      setUtilizador(user);
      return true;
    }

    // 🔥 fallback controlado
    const novoUser: Utilizador = {
      id: 'u-novo-' + Date.now(),
      nome: email.split('@')[0],
      email,
      telefone: '',
      provincia: 'Luanda',
      municipio: 'Belas',
      papel: 'cliente',
      tipo_comprador: 'casa',
    };

    setUtilizador(novoUser);

    return true; // ⚠️ manter por agora (mock), mas depois muda
  };

  const logout = () => {
    setUtilizador(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <AuthContexto.Provider
      value={{
        utilizador,
        login,
        logout,
        autenticado: !!utilizador,
        pronto,
        tipoComprador,
        atualizarTipoComprador,
      }}
    >
      {children}
    </AuthContexto.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContexto);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}