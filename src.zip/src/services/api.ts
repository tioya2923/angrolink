import { Produto, Vendedor } from "@/tipos";
import { supabase } from "./supabase";

// =============================
// UTILS (CRÍTICO)
// =============================
const toBool = (v: any, defaultValue = false) => {
  if (v === null || v === undefined) return defaultValue;
  return v === true || v === 'true' || v === 1;
};

// =============================
// FILTROS
// =============================
interface FetchProdutosParams {
  municipio?: string;
  tipoComprador?: 'casa' | 'negocio';
  categoria?: string;
  pesquisa?: string;
}

// =============================
// FETCH PRODUTOS
// =============================
export async function fetchProdutos(
  params?: FetchProdutosParams
): Promise<Produto[]> {

  let query = supabase
    .from("produtos")
    .select(`
      *,
      vendedor:vendedores (*),
      categoria:categorias (*)
    `);

  if (params?.categoria) {
    query = query.eq("categoria_id", params.categoria);
  }

  if (params?.municipio) {
    query = query.ilike("municipio", `%${params.municipio}%`);
  }

  if (params?.pesquisa) {
    query = query.ilike("nome_produto", `%${params.pesquisa}%`);
  }

  const { data, error } = await query;

  if (error) {
    console.error("Erro ao buscar produtos:", error);
    throw new Error("Erro ao carregar produtos");
  }

  let produtos = (data || []).map(p => ({
    ...p,
    destaque: toBool(p.destaque, false),
    disponivel: toBool(p.disponivel, true) // 🔥 CRÍTICO
  })) as Produto[];

  // =============================
  // FILTRO TIPO COMPRADOR
  // =============================
  if (params?.tipoComprador === 'casa') {
    produtos = produtos.filter(p =>
      p.tipo_venda === 'retalho' || p.tipo_venda === 'ambos'
    );
  }

  if (params?.tipoComprador === 'negocio') {
    produtos = produtos.filter(p =>
      p.tipo_venda === 'grosso' || p.tipo_venda === 'ambos'
    );
  }

  return produtos;
}

// =============================
// PRODUTO POR ID
// =============================
export async function fetchProdutoPorId(id: string): Promise<Produto | null> {

  const { data, error } = await supabase
    .from("produtos")
    .select(`
      *,
      vendedor:vendedores (*),
      categoria:categorias (*)
    `)
    .eq("id", id)
    .single();

  if (error) {
    console.error("Erro ao buscar produto:", error);
    return null;
  }

  return {
    ...data,
    destaque: toBool(data.destaque),
    disponivel: toBool(data.disponivel)
  } as Produto;
}

// =============================
// RELACIONADOS
// =============================
export async function fetchProdutosRelacionados(
  categoriaId: string,
  excluirId: string
): Promise<Produto[]> {

  const { data, error } = await supabase
    .from("produtos")
    .select(`
      *,
      vendedor:vendedores (*),
      categoria:categorias (*)
    `)
    .eq("categoria_id", categoriaId)
    .neq("id", excluirId)
    .eq("disponivel", true)
    .limit(4);

  if (error) {
    console.error("Erro ao buscar relacionados:", error);
    return [];
  }

  return (data || []).map(p => ({
    ...p,
    destaque: toBool(p.destaque),
    disponivel: toBool(p.disponivel)
  })) as Produto[];
}

// =============================
// VENDEDOR
// =============================
export async function fetchVendedorPorId(id: string): Promise<Vendedor | null> {
  const { data, error } = await supabase
    .from("vendedores")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    console.error("Erro ao buscar vendedor:", error);
    return null;
  }

  return data as Vendedor;
}

// =============================
// PRODUTOS DO VENDEDOR
// =============================
export async function fetchProdutosPorVendedor(
  vendedorId: string
): Promise<Produto[]> {
  console.log("QUERY vendedorId:", vendedorId);
  const { data, error } = await supabase
    .from("produtos")
    .select(`
      *,
      categoria:categorias (*)
    `)
    .eq("vendedor_id", vendedorId)
    //.eq("disponivel", true);
    console.log("RESULTADO RAW:", data);
    console.log("ERRO:", error);

  if (error) {
    console.error("Erro ao buscar produtos do vendedor:", error);
    return [];
  }

  return (data || []).map(p => ({
    ...p,
    destaque: toBool(p.destaque),
    disponivel: toBool(p.disponivel)
  })) as Produto[];

}

// =============================
// CATEGORIAS
// =============================
export async function fetchCategorias() {
  const { data, error } = await supabase
    .from("categorias")
    .select("*")
    .order("nome");

  if (error) {
    console.error("Erro ao buscar categorias:", error);
    return [];
  }

  return data;
}

// =============================
// UPLOAD IMAGEM
// =============================
export async function uploadImagemProduto(file: File) {
  const fileName = `${Date.now()}-${file.name}`;

  const { data, error } = await supabase.storage
    .from('produtos')
    .upload(fileName, file);

  if (error) {
    console.error('Erro upload imagem:', error);
    throw new Error('Erro ao enviar imagem');
  }

  const { data: publicUrl } = supabase
    .storage
    .from('produtos')
    .getPublicUrl(fileName);

  return publicUrl.publicUrl;
}

// =============================
// CRIAR PRODUTO
// =============================
interface CriarProdutoParams {
  nome_produto: string;
  descricao?: string;
  categoria_id: string;
  preco_aproximado: number;
  unidade: string;
  tipo_venda: 'retalho' | 'grosso' | 'ambos';
  municipio: string;
  provincia: string;
  imagem_url?: string;
}

export async function criarProduto(params: CriarProdutoParams) {

  const { data, error } = await supabase
    .from('produtos')
    .insert([
      {
        ...params,
        vendedor_id: "776d411d-922b-4908-bc02-32547b0f0277", // 🔥 FIXO
        disponivel: true,
      },
    ])
    .select()
    .single();

  if (error) {
    console.error('Erro ao criar produto:', error);
    throw new Error('Erro ao criar produto');
  }

  return data;
}