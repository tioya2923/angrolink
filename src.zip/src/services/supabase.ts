import { createClient } from '@supabase/supabase-js';

// A URL do Supabase é sempre baseada no ID do projeto
const supabaseUrl = 'https://wfgrldpemiorbkwpixgv.supabase.co';
const supabaseKey = 'sb_publishable_85MuR-P8f0YIVOw6aEbIeg_B7RrQFmd';

export const supabase = createClient(supabaseUrl, supabaseKey);