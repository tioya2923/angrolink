/**
 * ========================================
 * BARRA DE PESQUISA
 * ========================================
 * Campo de pesquisa com ícone de lupa.
 * Redireciona para a página de pesquisa ao submeter.
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';

export default function BarraPesquisa() {
  const [termo, setTermo] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (termo.trim()) {
      navigate(`/pesquisa?q=${encodeURIComponent(termo.trim())}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative">
      <input
        type="text"
        value={termo}
        onChange={e => setTermo(e.target.value)}
        placeholder="Pesquisar produtos..."
        className="w-full border-2 border-border bg-background text-foreground font-corpo text-sm px-4 py-3 pr-12 focus:outline-none focus:border-primary transition-colors"
        aria-label="Pesquisar produtos"
      />
      <button
        type="submit"
        className="absolute right-0 top-0 h-full px-4 text-foreground hover:text-primary transition-colors"
        aria-label="Pesquisar"
      >
        <Search size={20} />
      </button>
    </form>
  );
}
