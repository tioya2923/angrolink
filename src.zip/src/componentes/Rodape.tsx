/**
 * ========================================
 * RODAPÉ — Informações e links
 * ========================================
 */

import { Link } from 'react-router-dom';

export default function Rodape() {
  return (
    <footer className="border-t border-white/10 bg-slate-900 text-white/100 mt-12">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Sobre */}
          <div>
            <h3 className="font-titulo text-lg font-bold mb-3 text-white/100">ANGROLINK</h3>
            <p className="font-corpo text-sm text-white/100 leading-relaxed">
              Plataforma de visibilidade para produtores, revendedores e distribuidores
              agrícolas e alimentares em Angola.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-titulo text-sm mb-3 text-white/100">Navegação</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="font-corpo text-sm text-muted-foreground hover:text-primary transition-colors text-white/100">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/pesquisa" className="font-corpo text-sm text-muted-foreground hover:text-primary transition-colors text-white/100">
                  Produtos
                </Link>
              </li>
              <li>
                <Link to="/anunciar" className="font-corpo text-sm text-muted-foreground hover:text-primary transition-colors text-white/100">
                  Quero Anunciar
                </Link>
              </li>
            </ul>
          </div>

          {/* Contactos */}
          <div>
            <h4 className="font-titulo text-sm mb-3 text-white/100">Contactos</h4>
            <p className="font-corpo text-sm text-muted-foreground text-white/100">
              info@angrolink.co.ao
            </p>
            <p className="font-corpo text-sm text-muted-foreground mt-1 text-white/100">
              Luanda, Angola
            </p>
          </div>
        </div>

        {/* Linha inferior */}
        <div className="border-t border-border mt-8 pt-6 text-center">
          <p className="font-corpo text-xs text-muted-foreground text-white/100">
            © {new Date().getFullYear()} ANGROLINK. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
