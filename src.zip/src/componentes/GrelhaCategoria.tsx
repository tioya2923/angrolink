import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchCategorias } from '@/services/api';

import {
  Leaf,
  Wheat,
  Beef,
  Wine,
  UtensilsCrossed,
  Package,
  LucideIcon
} from 'lucide-react';

// Mapa fixo de ícones (controlado)
const MAPA_ICONES: Record<string, LucideIcon> = {
  alimentos: Wheat,
  bebidas: Wine,
  'pecuária': Beef,
  'produtos frescos': Leaf,
  'por grosso': Package,
  retalho: UtensilsCrossed,
};

export default function GrelhaCategoria() {
  const [categorias, setCategorias] = useState<any[]>([]);

  useEffect(() => {
    async function carregar() {
      const data = await fetchCategorias();
      setCategorias(data || []);
    }

    carregar();
  }, []);

  return (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-3 md:gap-4">
      {categorias.map(cat => {
        const nome = cat.nome.toLowerCase();
        const Icone = MAPA_ICONES[nome] || Package;

        return (
          <Link
            key={cat.id}
            to={`/pesquisa?categoria=${cat.id}`}
            className="flex flex-col items-center gap-2 p-4 border-2 border-border bg-background hover:border-primary transition-colors group"
          >
            <Icone
              size={28}
              className="text-foreground group-hover:text-primary transition-colors"
              fill="currentColor"
            />

            <span className="text-xs md:text-sm text-center">
              {cat.nome}
            </span>
          </Link>
        );
      })}
    </div>
  );
}