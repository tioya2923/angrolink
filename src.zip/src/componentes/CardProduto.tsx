/**
 * ========================================
 * CARD DE PRODUTO
 * ========================================
 * Inclui badge do tipo de vendedor, contexto de venda,
 * e preço duplo para produtos com tipo_venda = 'ambos'.
 */

import { Link } from 'react-router-dom';
import { ShieldCheck, MessageCircle } from 'lucide-react';
import { Produto } from '@/tipos';
import { obterVendedorPorId, gerarLinkWhatsApp } from '@/dados/mock';
import { obterBadgeVendedor } from '@/dados/constantes';
import { obterImagemProduto } from '@/dados/imagens';
import { useAuth } from '@/contextos/AuthContexto';

interface CardProdutoProps {
  produto: Produto;
}

function formatarPreco(valor?: number): string {
  if (typeof valor !== 'number') return '—';
  return new Intl.NumberFormat('pt-AO', {
    style: 'decimal',
    minimumFractionDigits: 0,
  }).format(valor);
}

export default function CardProduto({ produto }: CardProdutoProps) {
  const { tipoComprador } = useAuth();

  // 🔥 NOVO: usa Supabase primeiro, fallback para mock
  const vendedor =
    produto?.vendedor ??
    (produto?.vendedor_id
      ? obterVendedorPorId(produto.vendedor_id)
      : null);

  const imagem = obterImagemProduto(produto?.id) || '/placeholder.png';

  const badgeVendedor = vendedor
    ? obterBadgeVendedor(vendedor.tipo_vendedor)
    : null;

  const tipoVendaLabel =
    produto?.tipo_venda === 'grosso'
      ? 'Grosso'
      : produto?.tipo_venda === 'retalho'
      ? 'Retalho'
      : 'Grosso & Retalho';

  const mostrarDuploPreco =
    produto?.tipo_venda === 'ambos' && produto?.preco_grosso;

  return (
    <div className="card-produto overflow-hidden">
      
      {/* LINK PRINCIPAL */}
      <Link to={`/produto/${produto?.id}`} className="block">
        
        {/* Imagem */}
        <div className="aspect-square overflow-hidden relative">
          <img
            src={imagem}
            alt={produto?.nome_produto || 'Produto'}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/placeholder.png';
            }}
          />

          {badgeVendedor && (
            <span className="absolute top-2 left-2 px-2 py-0.5 bg-foreground/80 text-background text-[10px] rounded-sm">
              {badgeVendedor.rotulo}
            </span>
          )}

          <span className="absolute top-2 right-2 px-2 py-0.5 bg-primary/90 text-primary-foreground text-[10px] rounded-sm">
            {tipoVendaLabel}
          </span>
        </div>

        {/* Info */}
        <div className="p-3">
          <h3 className="font-titulo text-sm font-semibold leading-tight">
            {produto?.nome_produto || 'Produto'}
          </h3>

          {/* Preço */}
          {mostrarDuploPreco ? (
            <div className="mt-1.5">
              <p className="font-bold text-primary">
                {tipoComprador === 'negocio'
                  ? formatarPreco(produto?.preco_grosso)
                  : formatarPreco(produto?.preco_aproximado)} Kz
                <span className="text-xs text-muted-foreground ml-1">
                  / {produto?.unidade || '-'}
                </span>
              </p>
            </div>
          ) : (
            <p className="mt-1 font-bold text-primary">
              {formatarPreco(produto?.preco_aproximado)} Kz
              <span className="text-xs text-muted-foreground ml-1">
                / {produto?.unidade || '-'}
              </span>
            </p>
          )}

          <p className="text-xs text-muted-foreground mt-1">
            {produto?.municipio || ''}
          </p>
        </div>
      </Link>

      {/* FOOTER */}
      <div className="px-3 pb-3 flex items-center justify-between">

        {/* Vendedor */}
        {vendedor && (
          <Link
            to={`/vendedor/${vendedor.id}`}
            className="text-xs hover:text-primary flex items-center gap-1"
          >
            {vendedor.nome_comercial}
            {vendedor.verificado && <ShieldCheck size={12} />}
          </Link>
        )}

        {/* WhatsApp */}
        {vendedor && (
          <a
            href={gerarLinkWhatsApp(
              vendedor.telefone_whatsapp,
              produto?.nome_produto || ''
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-whatsapp flex items-center gap-1 px-2 py-1 text-xs"
          >
            <MessageCircle size={14} />
          </a>
        )}
      </div>
    </div>
  );
}