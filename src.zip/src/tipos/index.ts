/**
 * ========================================
 * TIPOS — Definições TypeScript
 * ========================================
 */

// =======================
// ENUMERAÇÕES
// =======================

export type TipoVendedor =
  | 'produtor'
  | 'distribuidor_grosso'
  | 'loja'
  | 'revendedor'
  | 'vendedor_mercado'
  | 'quinta';

export type StatusVendedorAprovacao =
  | 'pendente'
  | 'aprovado'
  | 'rejeitado'
  | 'suspenso';

export type TipoVenda = 'grosso' | 'retalho' | 'ambos';

export type PlanoVendedor = 'gratuito' | 'destaque' | 'premium';

export type StatusVendedor = 'ativo' | 'suspenso' | 'pendente';

export type StatusProduto = 'ativo' | 'inativo' | 'pendente';

export type UnidadeProduto =
  | 'kg'
  | 'saco'
  | 'caixa'
  | 'litro'
  | 'unidade'
  | 'animal';

export type PapelUtilizador = 'admin' | 'cliente' | 'vendedor';

export type TipoComprador = 'casa' | 'negocio';

// =======================
// LOCALIZAÇÃO
// =======================

export interface Provincia {
  id: string;
  nome: string;
}

export interface Municipio {
  id: string;
  nome: string;
  provincia_id: string;
}

// =======================
// CATEGORIA
// =======================

export interface Categoria {
  id: string;
  nome_categoria: string;
  icone: string;
  ordem_exibicao: number;
}

// =======================
// VENDEDOR
// =======================

export interface Vendedor {
  id: string;
  nome_comercial: string;
  nome_responsavel: string;
  telefone_whatsapp: string;

  provincia: string;
  municipio: string;

  mercado_bairro: string;
  bairro?: string;
  endereco_detalhado?: string;

  tipo_vendedor: TipoVendedor;

  descricao: string;

  foto_perfil: string;
  capa_loja?: string;
  fotos_local?: string[];

  verificado: boolean;

  // 🔒 Fase 2 (monetização)
  plano: PlanoVendedor;
  data_inicio_plano: string;
  data_fim_plano: string;

  status: StatusVendedor;
  status_aprovacao: StatusVendedorAprovacao;

  criado_em: string;

  // =======================
  // INFO ADICIONAL
  // =======================

  ano_inicio?: number;
  entrega_disponivel?: boolean;
  horario_atendimento?: string;
  tempo_resposta?: string;

  // =======================
  // CAMPOS ESPECÍFICOS
  // =======================

  tipo_producao?: string;
  area_cultivada?: number;
  principais_culturas?: string;
  producao_mensal?: string;

  tipos_produtos?: string;
  compra_produtores?: boolean;

  volume_minimo?: string;
  entrega_outras_provincias?: boolean;

  tipo_loja?: string;
  mercado_localizado?: string;
  venda_presencial?: boolean;
}

// =======================
// PRODUTO
// =======================

export interface Produto {
  id: string;

  nome_produto: string;

  categoria: string;
  subcategoria: string;

  preco_aproximado: number;
  unidade: UnidadeProduto;

  descricao: string;

  imagem_principal: string;
  imagens_secundarias: string[];

  disponivel: boolean;
  destaque: boolean;

  status: StatusProduto;

  vendedor_id: string;
  vendedor?: Vendedor;

  provincia: string;
  municipio: string;

  criado_em: string;
  atualizado_em: string;

  tipo_venda: TipoVenda;
  quantidade_minima: number;

  // 🟡 Fase 2 (analytics)
  visualizacoes?: number;
  cliques_whatsapp?: number;

  // 🟡 Fase 2 (grosso avançado)
  preco_grosso?: number;
  quantidade_minima_grosso?: number;
}

// =======================
// UTILIZADOR
// =======================

export interface Utilizador {
  id: string;
  nome: string;
  email: string;
  telefone: string;

  provincia: string;
  municipio: string;

  papel: PapelUtilizador;

  vendedor_id?: string;

  tipo_comprador?: TipoComprador;

  bairro?: string;
  endereco_detalhado?: string;
  whatsapp?: string;
  foto_perfil?: string;

  termos_aceites?: boolean;
}

// =======================
// CONTACTOS (MVP)
// =======================

export interface ContactoRecebido {
  id: string;
  produto_id: string;
  nome_produto: string;
  telefone_cliente: string;
  data: string;
}

export interface HistoricoContacto {
  id: string;
  vendedor_id: string;
  nome_vendedor: string;
  produto_id: string;
  nome_produto: string;
  data: string;
}

// =======================
// FORMULÁRIOS
// =======================

export interface FormularioVendedor {
  nome_comercial: string;
  nome_responsavel: string;
  telefone_whatsapp: string;
  email: string;
  senha: string;
  provincia: string;
  municipio: string;
  mercado_bairro: string;
  tipo_vendedor: TipoVendedor;
  descricao: string;
  foto_perfil?: File;
  foto_capa?: File;
}

export interface FormularioComprador {
  nome: string;
  telefone: string;
  email: string;
  senha: string;
  provincia: string;
  municipio: string;
}

// =======================
// PEDIDOS (FASE 2)
// =======================

export interface Pedido {
  id: string;
  produto_id: string;
  vendedor_id: string;

  comprador_nome: string;
  comprador_telefone: string;

  quantidade: number;
  valor_estimado: number;

  status: string;
  comissao_calculada: number;

  criado_em: string;
}