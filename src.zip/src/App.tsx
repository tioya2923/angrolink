/**
 * ========================================
 * APP — Raiz da aplicação
 * ========================================
 * Configuração de rotas e providers globais.
 */

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MunicipioProvider } from "@/contextos/MunicipioContexto";
import { AuthProvider } from "@/contextos/AuthContexto";

// Páginas
import PaginaInicial from "@/paginas/PaginaInicial";
import PaginaPesquisa from "@/paginas/PaginaPesquisa";
import PaginaProduto from "@/paginas/PaginaProduto";
import PaginaVendedor from "@/paginas/PaginaVendedor";
import PaginaAnunciar from "@/paginas/PaginaAnunciar";
import PaginaLogin from "@/paginas/PaginaLogin";
import DashboardRouter from "@/paginas/dashboard/DashboardRouter";
import ScrollToTop from "@/componentes/ScrollToTop";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <MunicipioProvider>
        <AuthProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <ScrollToTop />
            <Routes>
              {/* Páginas públicas */}
              <Route path="/" element={<PaginaInicial />} />
              <Route path="/pesquisa" element={<PaginaPesquisa />} />
              <Route path="/produto/:id" element={<PaginaProduto />} />
              <Route path="/vendedor/:id" element={<PaginaVendedor />} />
              <Route path="/anunciar" element={<PaginaAnunciar />} />
              
              {/* Autenticação */}
              <Route path="/login" element={<PaginaLogin />} />
              
              {/* Dashboard unificado (admin/vendedor/cliente) */}
              <Route path="/dashboard/*" element={<DashboardRouter />} />
              
              {/* Rota genérica — 404 */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </MunicipioProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
