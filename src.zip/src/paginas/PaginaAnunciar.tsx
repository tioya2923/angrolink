/**
 * ========================================
 * PÁGINA "CRIAR CONTA" — Sistema completo de registo
 * ========================================
 * Fluxo multi-etapa adaptado ao mercado agrícola angolano.
 * Registo simples e rápido, perfil completável depois.
 *
 * Etapas:
 * 1. Escolha: Comprar ou Vender
 * 2a. Formulário de comprador (campos obrigatórios + opcionais)
 * 2b. Seleção do tipo de vendedor
 * 3. Formulário de vendedor (Etapa 1: conta)
 * 4. Perfil comercial (Etapa 2: negócio + campos por tipo)
 * 5. Confirmação
 */

import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft, ShoppingBag, Megaphone, Send, Eye, EyeOff,
  CheckSquare, Camera, ChevronDown, ChevronUp,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PROVINCIAS, MUNICIPIOS, TIPOS_VENDEDOR } from '@/dados/constantes';
import { TipoVendedor, TipoComprador } from '@/tipos';
import { toast } from 'sonner';
import Cabecalho from '@/componentes/Cabecalho';
import Rodape from '@/componentes/Rodape';

type Etapa = 'escolha' | 'form-comprador' | 'tipo-vendedor' | 'form-vendedor' | 'perfil-comercial' | 'confirmacao';

// --- Classe reutilizável para selects ---
const selectClass = 'w-full h-10 border-2 border-border bg-background text-foreground font-corpo text-sm px-3 rounded-md focus:outline-none focus:ring-2 focus:ring-ring';
const selectDisabled = selectClass + ' disabled:opacity-50';

export default function PaginaAnunciar() {
  const [etapa, setEtapa] = useState<Etapa>('escolha');
  const [tipoVendedorSelecionado, setTipoVendedorSelecionado] = useState<TipoVendedor | ''>('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [mostrarOpcionais, setMostrarOpcionais] = useState(false);

  // ===== FORM COMPRADOR =====
  const [formComprador, setFormComprador] = useState({
    nome: '', telefone: '', email: '', senha: '',
    provincia: '', municipio: '', termos: false,
    // Opcionais
    bairro: '', endereco: '', whatsapp: '',
    tipo_comprador: 'casa' as TipoComprador,
  });

  // ===== FORM VENDEDOR (Etapa 1: Conta) =====
  const [formVendedor, setFormVendedor] = useState({
    nome_responsavel: '', telefone: '', email: '', senha: '',
    provincia: '', municipio: '', termos: false,
  });

  // ===== FORM PERFIL COMERCIAL (Etapa 2) =====
  const [formPerfil, setFormPerfil] = useState({
    nome_comercial: '', descricao: '', telefone_contacto: '', provincia_atividade: '',
    // Opcionais
    bairro: '', endereco: '', whatsapp: '', horario: '',
    ano_inicio: '', entrega_disponivel: false,
    // Campos por tipo
    tipo_producao: '', area_cultivada: '', principais_culturas: '', producao_mensal: '',
    venda_grosso: false, venda_retalho: false,
    tipos_produtos: '', compra_produtores: false,
    volume_minimo: '', entrega_outras_provincias: false,
    tipo_loja: '', mercado_localizado: '', venda_presencial: false,
  });

  const municipiosComprador = formComprador.provincia
    ? MUNICIPIOS.filter(m => m.provincia_id === formComprador.provincia) : [];
  const municipiosVendedor = formVendedor.provincia
    ? MUNICIPIOS.filter(m => m.provincia_id === formVendedor.provincia) : [];

  // --- Navegação ---
  const voltarEtapa = () => {
    if (etapa === 'form-comprador') setEtapa('escolha');
    else if (etapa === 'tipo-vendedor') setEtapa('escolha');
    else if (etapa === 'form-vendedor') setEtapa('tipo-vendedor');
    else if (etapa === 'perfil-comercial') setEtapa('form-vendedor');
  };

  // --- Submit comprador ---
  const handleSubmitComprador = (e: React.FormEvent) => {
    e.preventDefault();
    if (formComprador.senha.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    if (!formComprador.termos) {
      toast.error('Deve aceitar os termos da plataforma.');
      return;
    }
    setCarregando(true);
    // TODO (backend): Enviar dados para API — tipo_comprador definido automaticamente como 'casa'
    setTimeout(() => {
      setCarregando(false);
      setEtapa('confirmacao');
      toast.success('Conta de comprador criada!');
    }, 1000);
  };

  // --- Submit vendedor Etapa 1 ---
  const handleSubmitVendedorConta = (e: React.FormEvent) => {
    e.preventDefault();
    if (formVendedor.senha.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    if (!formVendedor.termos) {
      toast.error('Deve aceitar os termos da plataforma.');
      return;
    }
    setEtapa('perfil-comercial');
  };

  // --- Submit vendedor Etapa 2 (perfil comercial) ---
  const handleSubmitPerfilComercial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formPerfil.nome_comercial || !formPerfil.descricao || !formPerfil.telefone_contacto || !formPerfil.provincia_atividade) {
      toast.error('Preencha todos os campos obrigatórios do perfil comercial.');
      return;
    }
    setCarregando(true);
    // TODO (backend): Enviar dados para API — status_vendedor = 'pendente', tipo_comprador = 'negocio'
    setTimeout(() => {
      setCarregando(false);
      setEtapa('confirmacao');
      toast.success('Pedido enviado para aprovação!');
    }, 1000);
  };

  const selecionarTipoVendedor = (tipo: TipoVendedor) => {
    setTipoVendedorSelecionado(tipo);
    setEtapa('form-vendedor');
  };

  // --- Barra de progresso ---
  const etapaNumero = etapa === 'escolha' ? 1
    : etapa === 'form-comprador' ? 2
    : etapa === 'tipo-vendedor' ? 2
    : etapa === 'form-vendedor' ? 3
    : etapa === 'perfil-comercial' ? 4 : 5;
  const totalEtapas = etapa === 'form-comprador' ? 3 : 5;

  // ===== CONFIRMAÇÃO =====
  if (etapa === 'confirmacao') {
    const isVendedor = !!tipoVendedorSelecionado;
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center py-12">
          <div className="container max-w-lg text-center space-y-4">
            <div className="w-16 h-16 bg-primary mx-auto flex items-center justify-center rounded-md">
              <Send size={28} className="text-primary-foreground" />
            </div>
            <h1 className="font-titulo text-2xl">
              {isVendedor ? 'Pedido Enviado!' : 'Conta Criada!'}
            </h1>
            <p className="font-corpo text-sm text-muted-foreground leading-relaxed">
              {isVendedor
                ? 'A sua conta foi criada com o estado pendente. A equipa Angrolink irá analisar o seu perfil antes de aprovar. Entraremos em contacto pelo WhatsApp informado dentro de 24 a 48 horas.'
                : 'A sua conta de comprador foi criada com sucesso. Já pode explorar produtos e contactar vendedores.'}
            </p>
            {isVendedor && (
              <div className="border-2 border-border bg-muted/30 p-4 rounded-md text-left">
                <p className="font-corpo text-xs text-muted-foreground">
                  <strong>Próximos passos:</strong>
                </p>
                <ul className="font-corpo text-xs text-muted-foreground mt-2 space-y-1 list-disc list-inside">
                  <li>Aguarde a aprovação da sua conta</li>
                  <li>Após aprovação, poderá publicar produtos</li>
                  <li>Complete o seu perfil no dashboard para mais visibilidade</li>
                </ul>
              </div>
            )}
            <Link to="/" className="inline-block mt-4">
              <Button className="font-corpo">Ir para a página inicial</Button>
            </Link>
          </div>
        </main>
        <Rodape />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Cabecalho />

      <main className="flex-1 py-8">
        <div className="container max-w-2xl">

          {/* Barra de progresso */}
          {etapa !== 'escolha' && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={voltarEtapa}
                  className="flex items-center gap-2 font-corpo text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Voltar
                </button>
                <span className="font-corpo text-xs text-muted-foreground">
                  Etapa {etapaNumero} de {totalEtapas}
                </span>
              </div>
              <div className="w-full h-1.5 bg-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${(etapaNumero / totalEtapas) * 100}%` }}
                />
              </div>
            </div>
          )}

          {/* ===== ETAPA 1: ESCOLHA ===== */}
          {etapa === 'escolha' && (
            <div className="space-y-6">
              <div className="text-center">
                <h1 className="font-titulo text-2xl md:text-3xl">
                  Quero usar a plataforma para:
                </h1>
                <p className="font-corpo text-sm text-muted-foreground mt-2">
                  Escolha o tipo de conta que melhor se adequa a si.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  onClick={() => setEtapa('form-comprador')}
                  className="border-2 border-border bg-card p-6 text-left hover:border-primary transition-colors group rounded-md"
                >
                  <div className="w-12 h-12 bg-primary/10 flex items-center justify-center rounded-md mb-4 group-hover:bg-primary/20 transition-colors">
                    <ShoppingBag className="w-6 h-6 text-primary" />
                  </div>
                  <h2 className="font-titulo text-lg mb-2">Comprar</h2>
                  <p className="font-corpo text-sm text-muted-foreground leading-relaxed">
                    Encontre produtores, distribuidores e vendedores perto de si.
                    Contacte vendedores diretamente via WhatsApp.
                  </p>
                  <span className="inline-block mt-4 font-corpo text-sm font-semibold text-primary">
                    Criar conta de comprador →
                  </span>
                </button>

                <button
                  onClick={() => setEtapa('tipo-vendedor')}
                  className="border-2 border-border bg-card p-6 text-left hover:border-secondary transition-colors group rounded-md"
                >
                  <div className="w-12 h-12 bg-secondary/20 flex items-center justify-center rounded-md mb-4 group-hover:bg-secondary/30 transition-colors">
                    <Megaphone className="w-6 h-6 text-secondary-foreground" />
                  </div>
                  <h2 className="font-titulo text-lg mb-2">Vender</h2>
                  <p className="font-corpo text-sm text-muted-foreground leading-relaxed">
                    Publique os seus produtos e receba contactos de compradores em todo o país.
                  </p>
                  <span className="inline-block mt-4 font-corpo text-sm font-semibold text-secondary-foreground">
                    Criar conta de vendedor →
                  </span>
                </button>
              </div>

              <p className="text-center font-corpo text-sm text-muted-foreground">
                Já tem conta?{' '}
                <Link to="/login" className="text-primary hover:underline font-medium">
                  Entrar aqui
                </Link>
              </p>
            </div>
          )}

          {/* ===== ETAPA 2a: FORMULÁRIO COMPRADOR ===== */}
          {etapa === 'form-comprador' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-titulo text-2xl md:text-3xl">Criar conta de comprador</h1>
                <p className="font-corpo text-sm text-muted-foreground mt-1">
                  Preencha os dados abaixo para começar a explorar produtos.
                </p>
              </div>

              <form onSubmit={handleSubmitComprador} className="border-2 border-border bg-card p-6 rounded-md space-y-4">
                {/* Campos obrigatórios */}
                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Nome completo *</Label>
                  <Input value={formComprador.nome} onChange={e => setFormComprador(p => ({ ...p, nome: e.target.value }))}
                    placeholder="O seu nome completo" required className="border-2 border-border" maxLength={100} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Número de telefone *</Label>
                  <Input type="tel" value={formComprador.telefone} onChange={e => setFormComprador(p => ({ ...p, telefone: e.target.value }))}
                    placeholder="Ex: 923 456 789" required className="border-2 border-border" maxLength={20} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Email *</Label>
                  <Input type="email" value={formComprador.email} onChange={e => setFormComprador(p => ({ ...p, email: e.target.value }))}
                    placeholder="exemplo@email.com" required className="border-2 border-border" maxLength={255} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Senha *</Label>
                  <div className="relative">
                    <Input type={mostrarSenha ? 'text' : 'password'} value={formComprador.senha}
                      onChange={e => setFormComprador(p => ({ ...p, senha: e.target.value }))}
                      placeholder="Mínimo 6 caracteres" required className="border-2 border-border pr-10" maxLength={128} />
                    <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {mostrarSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Província *</Label>
                    <select value={formComprador.provincia}
                      onChange={e => setFormComprador(p => ({ ...p, provincia: e.target.value, municipio: '' }))}
                      className={selectClass} required>
                      <option value="">Selecione</option>
                      {PROVINCIAS.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Município *</Label>
                    <select value={formComprador.municipio}
                      onChange={e => setFormComprador(p => ({ ...p, municipio: e.target.value }))}
                      disabled={!formComprador.provincia}
                      className={selectDisabled} required>
                      <option value="">Selecione</option>
                      {municipiosComprador.map(m => <option key={m.id} value={m.id}>{m.nome}</option>)}
                    </select>
                  </div>
                </div>

                {/* Termos */}
                <label className="flex items-start gap-3 cursor-pointer py-2">
                  <input type="checkbox" checked={formComprador.termos}
                    onChange={e => setFormComprador(p => ({ ...p, termos: e.target.checked }))}
                    className="mt-0.5 w-4 h-4 accent-primary" />
                  <span className="font-corpo text-xs text-muted-foreground leading-relaxed">
                    Aceito os <Link to="#" className="text-primary underline">termos e condições</Link> e a{' '}
                    <Link to="#" className="text-primary underline">política de privacidade</Link> da plataforma Angrolink. *
                  </span>
                </label>

                {/* Campos opcionais (colapsáveis) */}
                <button
                  type="button"
                  onClick={() => setMostrarOpcionais(!mostrarOpcionais)}
                  className="flex items-center gap-2 font-corpo text-xs text-primary hover:underline"
                >
                  {mostrarOpcionais ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  {mostrarOpcionais ? 'Ocultar campos opcionais' : 'Mostrar campos opcionais'}
                </button>

                {mostrarOpcionais && (
                  <div className="space-y-4 border-t border-border pt-4">
                    <p className="font-corpo text-xs text-muted-foreground italic">
                      Pode preencher depois no seu perfil.
                    </p>

                    <div className="space-y-2">
                      <Label className="font-corpo text-sm font-medium">WhatsApp</Label>
                      <Input type="tel" value={formComprador.whatsapp}
                        onChange={e => setFormComprador(p => ({ ...p, whatsapp: e.target.value }))}
                        placeholder="Ex: 923 456 789" className="border-2 border-border" maxLength={20} />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="font-corpo text-sm font-medium">Bairro</Label>
                        <Input value={formComprador.bairro}
                          onChange={e => setFormComprador(p => ({ ...p, bairro: e.target.value }))}
                          placeholder="Ex: Morro Bento" className="border-2 border-border" maxLength={100} />
                      </div>
                      <div className="space-y-2">
                        <Label className="font-corpo text-sm font-medium">Endereço detalhado</Label>
                        <Input value={formComprador.endereco}
                          onChange={e => setFormComprador(p => ({ ...p, endereco: e.target.value }))}
                          placeholder="Rua, número..." className="border-2 border-border" maxLength={200} />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="font-corpo text-sm font-medium">Preferência de compra</Label>
                      <div className="flex gap-3">
                        {(['casa', 'negocio'] as TipoComprador[]).map(tipo => (
                          <label key={tipo} className="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="tipo_comprador" value={tipo}
                              checked={formComprador.tipo_comprador === tipo}
                              onChange={() => setFormComprador(p => ({ ...p, tipo_comprador: tipo }))}
                              className="accent-primary" />
                            <span className="font-corpo text-sm">
                              {tipo === 'casa' ? 'Para casa' : 'Para negócio'}
                            </span>
                          </label>
                        ))}
                      </div>
                      <p className="font-corpo text-xs text-muted-foreground">
                        Define o tipo de produtos que verá na plataforma.
                      </p>
                    </div>

                    {/* Upload foto — placeholder */}
                    <div className="border-2 border-dashed border-border p-4 rounded-md text-center">
                      <Camera size={20} className="mx-auto text-muted-foreground mb-1" />
                      <p className="font-corpo text-xs text-muted-foreground">
                        Foto de perfil — disponível em breve
                      </p>
                    </div>
                  </div>
                )}

                <Button type="submit" disabled={carregando} className="w-full font-corpo font-semibold mt-2">
                  {carregando ? 'A criar...' : 'Criar conta de comprador'}
                </Button>
              </form>
            </div>
          )}

          {/* ===== ETAPA 2b: TIPO DE VENDEDOR ===== */}
          {etapa === 'tipo-vendedor' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-titulo text-2xl md:text-3xl">Que tipo de vendedor é você?</h1>
                <p className="font-corpo text-sm text-muted-foreground mt-1">
                  Selecione o tipo que melhor descreve o seu negócio.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {TIPOS_VENDEDOR.map(tipo => (
                  <button
                    key={tipo.valor}
                    onClick={() => selecionarTipoVendedor(tipo.valor)}
                    className="border-2 border-border bg-card p-5 text-left hover:border-primary transition-colors rounded-md group"
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">{tipo.icone}</span>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-titulo text-sm font-semibold">{tipo.rotulo}</h3>
                        <p className="font-corpo text-xs text-muted-foreground mt-1 leading-relaxed">
                          {tipo.descricao}
                        </p>
                        <p className="font-corpo text-xs text-muted-foreground/70 mt-1 italic">
                          Ex: {tipo.exemplos}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ===== ETAPA 3: CONTA DE VENDEDOR ===== */}
          {etapa === 'form-vendedor' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-titulo text-2xl md:text-3xl">Criar conta de vendedor</h1>
                <div className="flex items-center gap-2 mt-2">
                  {tipoVendedorSelecionado && (() => {
                    const t = TIPOS_VENDEDOR.find(tv => tv.valor === tipoVendedorSelecionado);
                    return t ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/10 text-primary font-corpo text-xs font-medium rounded-md">
                        {t.icone} {t.rotulo}
                      </span>
                    ) : null;
                  })()}
                </div>
                <p className="font-corpo text-sm text-muted-foreground mt-2">
                  Etapa 1: Dados da conta. A seguir preencherá o perfil do negócio.
                </p>
              </div>

              <form onSubmit={handleSubmitVendedorConta} className="border-2 border-border bg-card p-6 rounded-md space-y-4">
                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Nome do responsável *</Label>
                  <Input value={formVendedor.nome_responsavel}
                    onChange={e => setFormVendedor(p => ({ ...p, nome_responsavel: e.target.value }))}
                    placeholder="Nome completo" required className="border-2 border-border" maxLength={100} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Número de telefone *</Label>
                  <Input type="tel" value={formVendedor.telefone}
                    onChange={e => setFormVendedor(p => ({ ...p, telefone: e.target.value }))}
                    placeholder="Ex: 923 456 789" required className="border-2 border-border" maxLength={20} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Email *</Label>
                  <Input type="email" value={formVendedor.email}
                    onChange={e => setFormVendedor(p => ({ ...p, email: e.target.value }))}
                    placeholder="exemplo@email.com" required className="border-2 border-border" maxLength={255} />
                </div>

                <div className="space-y-2">
                  <Label className="font-corpo text-sm font-medium">Senha *</Label>
                  <div className="relative">
                    <Input type={mostrarSenha ? 'text' : 'password'} value={formVendedor.senha}
                      onChange={e => setFormVendedor(p => ({ ...p, senha: e.target.value }))}
                      placeholder="Mínimo 6 caracteres" required className="border-2 border-border pr-10" maxLength={128} />
                    <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {mostrarSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Província *</Label>
                    <select value={formVendedor.provincia}
                      onChange={e => setFormVendedor(p => ({ ...p, provincia: e.target.value, municipio: '' }))}
                      className={selectClass} required>
                      <option value="">Selecione</option>
                      {PROVINCIAS.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Município *</Label>
                    <select value={formVendedor.municipio}
                      onChange={e => setFormVendedor(p => ({ ...p, municipio: e.target.value }))}
                      disabled={!formVendedor.provincia}
                      className={selectDisabled} required>
                      <option value="">Selecione</option>
                      {municipiosVendedor.map(m => <option key={m.id} value={m.id}>{m.nome}</option>)}
                    </select>
                  </div>
                </div>

                {/* Termos */}
                <label className="flex items-start gap-3 cursor-pointer py-2">
                  <input type="checkbox" checked={formVendedor.termos}
                    onChange={e => setFormVendedor(p => ({ ...p, termos: e.target.checked }))}
                    className="mt-0.5 w-4 h-4 accent-primary" />
                  <span className="font-corpo text-xs text-muted-foreground leading-relaxed">
                    Aceito os <Link to="#" className="text-primary underline">termos e condições</Link> e a{' '}
                    <Link to="#" className="text-primary underline">política de privacidade</Link> da plataforma Angrolink. *
                  </span>
                </label>

                <Button type="submit" className="w-full font-corpo font-semibold mt-2">
                  Continuar para perfil do negócio →
                </Button>
              </form>
            </div>
          )}

          {/* ===== ETAPA 4: PERFIL COMERCIAL ===== */}
          {etapa === 'perfil-comercial' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-titulo text-2xl md:text-3xl">Perfil do negócio</h1>
                <p className="font-corpo text-sm text-muted-foreground mt-1">
                  Etapa 2: Complete os dados do seu negócio para poder publicar produtos.
                </p>
              </div>

              <form onSubmit={handleSubmitPerfilComercial} className="border-2 border-border bg-card p-6 rounded-md space-y-5">
                {/* Campos obrigatórios do perfil comercial */}
                <div className="space-y-4">
                  <h3 className="font-titulo text-sm font-semibold flex items-center gap-2">
                    <CheckSquare size={16} className="text-primary" />
                    Informação obrigatória
                  </h3>

                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Nome do negócio *</Label>
                    <Input value={formPerfil.nome_comercial}
                      onChange={e => setFormPerfil(p => ({ ...p, nome_comercial: e.target.value }))}
                      placeholder="Ex: Horta da Dona Maria" required className="border-2 border-border" maxLength={100} />
                  </div>

                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Descrição curta do negócio *</Label>
                    <textarea value={formPerfil.descricao}
                      onChange={e => setFormPerfil(p => ({ ...p, descricao: e.target.value }))}
                      placeholder="Descreva brevemente o que vende e como funciona o seu negócio..."
                      rows={3} maxLength={500} required
                      className="w-full border-2 border-border bg-background text-foreground font-corpo text-sm px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                  </div>

                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Telefone de contacto *</Label>
                    <Input type="tel" value={formPerfil.telefone_contacto}
                      onChange={e => setFormPerfil(p => ({ ...p, telefone_contacto: e.target.value }))}
                      placeholder="Ex: 923 456 789" required className="border-2 border-border" maxLength={20} />
                  </div>

                  <div className="space-y-2">
                    <Label className="font-corpo text-sm font-medium">Província de atividade *</Label>
                    <select value={formPerfil.provincia_atividade}
                      onChange={e => setFormPerfil(p => ({ ...p, provincia_atividade: e.target.value }))}
                      className={selectClass} required>
                      <option value="">Selecione</option>
                      {PROVINCIAS.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
                    </select>
                  </div>
                </div>

                {/* Campos opcionais gerais */}
                <div className="border-t border-border pt-4 space-y-4">
                  <button
                    type="button"
                    onClick={() => setMostrarOpcionais(!mostrarOpcionais)}
                    className="flex items-center gap-2 font-corpo text-xs text-primary hover:underline"
                  >
                    {mostrarOpcionais ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    {mostrarOpcionais ? 'Ocultar campos opcionais' : 'Campos opcionais (pode preencher depois)'}
                  </button>

                  {mostrarOpcionais && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="font-corpo text-sm font-medium">WhatsApp</Label>
                          <Input type="tel" value={formPerfil.whatsapp}
                            onChange={e => setFormPerfil(p => ({ ...p, whatsapp: e.target.value }))}
                            placeholder="Ex: 923 456 789" className="border-2 border-border" maxLength={20} />
                        </div>
                        <div className="space-y-2">
                          <Label className="font-corpo text-sm font-medium">Ano de início da atividade</Label>
                          <Input type="number" value={formPerfil.ano_inicio}
                            onChange={e => setFormPerfil(p => ({ ...p, ano_inicio: e.target.value }))}
                            placeholder="Ex: 2020" className="border-2 border-border" min={1950} max={2026} />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="font-corpo text-sm font-medium">Bairro</Label>
                          <Input value={formPerfil.bairro}
                            onChange={e => setFormPerfil(p => ({ ...p, bairro: e.target.value }))}
                            placeholder="Ex: Kikolo" className="border-2 border-border" maxLength={100} />
                        </div>
                        <div className="space-y-2">
                          <Label className="font-corpo text-sm font-medium">Endereço detalhado</Label>
                          <Input value={formPerfil.endereco}
                            onChange={e => setFormPerfil(p => ({ ...p, endereco: e.target.value }))}
                            placeholder="Rua, número..." className="border-2 border-border" maxLength={200} />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="font-corpo text-sm font-medium">Horário de atendimento</Label>
                        <Input value={formPerfil.horario}
                          onChange={e => setFormPerfil(p => ({ ...p, horario: e.target.value }))}
                          placeholder="Ex: Seg-Sáb 7h-17h" className="border-2 border-border" maxLength={100} />
                      </div>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input type="checkbox" checked={formPerfil.entrega_disponivel}
                          onChange={e => setFormPerfil(p => ({ ...p, entrega_disponivel: e.target.checked }))}
                          className="w-4 h-4 accent-primary" />
                        <span className="font-corpo text-sm">Entrega disponível</span>
                      </label>

                      {/* Upload fotos — placeholder */}
                      <div className="border-2 border-dashed border-border p-4 rounded-md text-center">
                        <Camera size={20} className="mx-auto text-muted-foreground mb-1" />
                        <p className="font-corpo text-xs text-muted-foreground">
                          Foto de perfil, logo e fotos do local — disponível em breve
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Campos específicos por tipo de vendedor */}
                <CamposPorTipo tipo={tipoVendedorSelecionado as TipoVendedor} form={formPerfil} setForm={setFormPerfil} />

                <Button type="submit" disabled={carregando} className="w-full font-corpo font-semibold mt-2">
                  <Send className="w-4 h-4 mr-2" />
                  {carregando ? 'A enviar...' : 'Enviar para aprovação'}
                </Button>
              </form>
            </div>
          )}
        </div>
      </main>

      <Rodape />
    </div>
  );
}

// ===== COMPONENTE: Campos específicos por tipo de vendedor =====
function CamposPorTipo({
  tipo, form, setForm,
}: {
  tipo: TipoVendedor;
  form: Record<string, any>;
  setForm: React.Dispatch<React.SetStateAction<any>>;
}) {
  const tipoInfo = TIPOS_VENDEDOR.find(t => t.valor === tipo);
  if (!tipoInfo) return null;

  const isProdutor = tipo === 'produtor' || tipo === 'quinta';
  const isRevendedor = tipo === 'revendedor' || tipo === 'vendedor_mercado';
  const isDistribuidor = tipo === 'distribuidor_grosso';
  const isLoja = tipo === 'loja';

  return (
    <div className="border-t border-border pt-4 space-y-4">
      <h3 className="font-titulo text-sm font-semibold flex items-center gap-2">
        <span>{tipoInfo.icone}</span>
        Informação específica — {tipoInfo.rotulo}
      </h3>
      <p className="font-corpo text-xs text-muted-foreground italic">
        Campos opcionais. Pode preencher depois no dashboard.
      </p>

      {/* Produtor / Quinta / Fazenda */}
      {isProdutor && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="font-corpo text-sm font-medium">Tipo de produção</Label>
            <Input value={form.tipo_producao}
              onChange={e => setForm((p: any) => ({ ...p, tipo_producao: e.target.value }))}
              placeholder="Ex: Horticultura, Pecuária, Mista" className="border-2 border-border" maxLength={100} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="font-corpo text-sm font-medium">Área cultivada (hectares)</Label>
              <Input type="number" value={form.area_cultivada}
                onChange={e => setForm((p: any) => ({ ...p, area_cultivada: e.target.value }))}
                placeholder="Ex: 5" className="border-2 border-border" min={0} />
            </div>
            <div className="space-y-2">
              <Label className="font-corpo text-sm font-medium">Produção estimada mensal</Label>
              <Input value={form.producao_mensal}
                onChange={e => setForm((p: any) => ({ ...p, producao_mensal: e.target.value }))}
                placeholder="Ex: 500 kg de tomate" className="border-2 border-border" maxLength={200} />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm font-medium">Principais culturas</Label>
            <Input value={form.principais_culturas}
              onChange={e => setForm((p: any) => ({ ...p, principais_culturas: e.target.value }))}
              placeholder="Ex: Milho, Feijão, Tomate" className="border-2 border-border" maxLength={200} />
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.venda_grosso}
                onChange={e => setForm((p: any) => ({ ...p, venda_grosso: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Venda a grosso</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.venda_retalho}
                onChange={e => setForm((p: any) => ({ ...p, venda_retalho: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Venda a retalho</span>
            </label>
          </div>
        </div>
      )}

      {/* Revendedor / Vendedor de mercado */}
      {isRevendedor && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="font-corpo text-sm font-medium">Tipos de produtos vendidos</Label>
            <Input value={form.tipos_produtos}
              onChange={e => setForm((p: any) => ({ ...p, tipos_produtos: e.target.value }))}
              placeholder="Ex: Frutas, Hortaliças, Cereais" className="border-2 border-border" maxLength={200} />
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.compra_produtores}
                onChange={e => setForm((p: any) => ({ ...p, compra_produtores: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Compra diretamente de produtores</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.venda_retalho}
                onChange={e => setForm((p: any) => ({ ...p, venda_retalho: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Venda a retalho</span>
            </label>
          </div>
        </div>
      )}

      {/* Distribuidor / Venda por grosso */}
      {isDistribuidor && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="font-corpo text-sm font-medium">Tipos de produtos</Label>
            <Input value={form.tipos_produtos}
              onChange={e => setForm((p: any) => ({ ...p, tipos_produtos: e.target.value }))}
              placeholder="Ex: Bebidas, Cereais, Conservas" className="border-2 border-border" maxLength={200} />
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm font-medium">Volume mínimo de venda</Label>
            <Input value={form.volume_minimo}
              onChange={e => setForm((p: any) => ({ ...p, volume_minimo: e.target.value }))}
              placeholder="Ex: 10 sacos, 1 palete" className="border-2 border-border" maxLength={100} />
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.entrega_outras_provincias}
              onChange={e => setForm((p: any) => ({ ...p, entrega_outras_provincias: e.target.checked }))}
              className="w-4 h-4 accent-primary" />
            <span className="font-corpo text-sm">Entrega para outras províncias</span>
          </label>
        </div>
      )}

      {/* Loja / Mercado */}
      {isLoja && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="font-corpo text-sm font-medium">Tipo de loja</Label>
              <select value={form.tipo_loja}
                onChange={e => setForm((p: any) => ({ ...p, tipo_loja: e.target.value }))}
                className={selectClass}>
                <option value="">Selecione</option>
                <option value="mercearia">Mercearia</option>
                <option value="mini-mercado">Mini-mercado</option>
                <option value="loja-bairro">Loja de bairro</option>
                <option value="supermercado">Supermercado</option>
                <option value="outro">Outro</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label className="font-corpo text-sm font-medium">Mercado onde está localizado</Label>
              <Input value={form.mercado_localizado}
                onChange={e => setForm((p: any) => ({ ...p, mercado_localizado: e.target.value }))}
                placeholder="Ex: Mercado do Kikolo" className="border-2 border-border" maxLength={100} />
            </div>
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.venda_presencial}
                onChange={e => setForm((p: any) => ({ ...p, venda_presencial: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Venda presencial</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.entrega_disponivel}
                onChange={e => setForm((p: any) => ({ ...p, entrega_disponivel: e.target.checked }))}
                className="w-4 h-4 accent-primary" />
              <span className="font-corpo text-sm">Entrega disponível</span>
            </label>
          </div>
        </div>
      )}
    </div>
  );
}
