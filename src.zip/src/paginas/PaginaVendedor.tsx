/**
 * ========================================
 * PÁGINA DO VENDEDOR (Perfil / Loja)
 * ========================================
 * Foto perfil, capa, informações, lista de produtos.
 * Botão WhatsApp direto.
 */

import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { MessageCircle, ShieldCheck, ArrowLeft, MapPin } from 'lucide-react';

import Cabecalho from '@/componentes/Cabecalho';
import Rodape from '@/componentes/Rodape';
import ListaProdutos from '@/componentes/ListaProdutos';

import {
  fetchVendedorPorId,
  fetchProdutosPorVendedor
} from '@/services/api';

import { gerarLinkWhatsApp } from '@/dados/mock';

import { Vendedor, Produto } from '@/tipos';

// =============================
// HELPERS
// =============================

// 🔥 Label amigável para tipo de vendedor
const tipoVendedorLabel: Record<string, string> = {
  produtor: 'Produtor',
  revendedor: 'Revendedor',
  grosso: 'Venda por Grosso',
  loja: 'Loja / Mercado',
  fazenda: 'Quinta / Fazenda',
  mercado: 'Vendedor de Mercado',
};

// 🔥 fallback imagem
const getImagemPerfil = (img?: string | null) =>
  img || '/placeholder.png';

// 🔥 ordenação de produtos
const ordenarProdutos = (produtos: Produto[]) => {
  return [...produtos].sort((a, b) => {
    if (a.disponivel !== b.disponivel) {
      return a.disponivel ? -1 : 1;
    }

    return (
      new Date(b.criado_em || 0).getTime() -
      new Date(a.criado_em || 0).getTime()
    );
  });
};

export default function PaginaVendedor() {
  const { id } = useParams<{ id: string }>();

  const [vendedor, setVendedor] = useState<Vendedor | null>(null);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    async function carregar() {
      console.log("Página vendedor → ID recebido:", id);

      if (!id) {
        setErro("ID inválido");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setErro(null);

        const vendedorData = await fetchVendedorPorId(id);

        if (!vendedorData) {
          setErro("Vendedor não encontrado");
          setVendedor(null);
          setProdutos([]);
          return;
        }

        setVendedor(vendedorData);

        const produtosData = await fetchProdutosPorVendedor(vendedorData.id);
        setProdutos(produtosData);

      } catch (err) {
        console.error("Erro ao carregar vendedor:", err);
        setErro("Erro ao carregar dados");
      } finally {
        setLoading(false);
      }
    }

    carregar();
  }, [id]);

  // =============================
  // LOADING
  // =============================
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center">
          <p className="font-corpo text-muted-foreground">
            A carregar vendedor...
          </p>
        </main>
        <Rodape />
      </div>
    );
  }

  // =============================
  // ERRO
  // =============================
  if (erro) {
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center">
          <p className="font-corpo text-muted-foreground">{erro}</p>
        </main>
        <Rodape />
      </div>
    );
  }

  // =============================
  // NÃO ENCONTRADO
  // =============================
  if (!vendedor) {
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center">
          <p className="font-corpo text-muted-foreground">
            Vendedor não encontrado.
          </p>
        </main>
        <Rodape />
      </div>
    );
  }

  // =============================
  // PLANOS
  // =============================
  const rotuloPlan: Record<string, string> = {
    gratuito: 'Plano Gratuito',
    destaque: 'Plano Destaque',
    premium: 'Plano Premium',
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Cabecalho />

      <main className="flex-1">

        {/* CAPA */}
        <div className="h-32 md:h-48 bg-muted border-b-2 border-border" />

        <div className="container -mt-12 md:-mt-16">

          {/* HEADER */}
          <div className="flex items-end gap-4 mb-6">
            <div className="w-24 h-24 md:w-32 md:h-32 border-4 border-background bg-muted overflow-hidden flex-shrink-0">
              <img
                src={getImagemPerfil(vendedor.foto_perfil)}
                alt={vendedor.nome_comercial}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/placeholder.png';
                }}
              />
            </div>

            <div className="pb-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="font-titulo text-xl md:text-2xl">
                  {vendedor.nome_comercial}
                </h1>

                {vendedor.verificado && (
                  <span className="selo-verificado">
                    <ShieldCheck size={14} />
                    Verificado
                  </span>
                )}
              </div>

              <p className="font-corpo text-sm text-muted-foreground flex items-center gap-1 mt-1">
                <MapPin size={14} />
                {vendedor.mercado_bairro}, {vendedor.municipio} — {vendedor.provincia}
              </p>
            </div>
          </div>

          {/* VOLTAR */}
          <Link
            to="/pesquisa"
            className="inline-flex items-center gap-1 font-corpo text-sm text-muted-foreground hover:text-primary mb-4"
          >
            <ArrowLeft size={16} />
            Voltar
          </Link>

          {/* DESCRIÇÃO */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

            <div className="md:col-span-2 space-y-3">
              <p className="font-corpo text-sm text-muted-foreground leading-relaxed">
                {vendedor.descricao || 'Sem descrição'}
              </p>

              <p className="font-corpo text-xs text-muted-foreground">
                Tipo:{' '}
                <span className="text-foreground">
                  {tipoVendedorLabel[vendedor.tipo_vendedor] || vendedor.tipo_vendedor}
                </span>
                {' · '}
                {rotuloPlan[vendedor.plano]}
              </p>
            </div>

            {/* WHATSAPP */}
            <div>
              <a
                href={gerarLinkWhatsApp(
                  vendedor.telefone_whatsapp,
                  `loja ${vendedor.nome_comercial}`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp w-full flex items-center justify-center gap-2 border-2 border-foreground"
              >
                <MessageCircle size={18} />
                Contactar no WhatsApp
              </a>
            </div>

          </div>

          {/* PRODUTOS */}
          <section className="border-t-2 border-border pt-6">

            {produtos.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Este vendedor ainda não tem produtos disponíveis.
              </p>
            ) : (
              <ListaProdutos
                produtos={ordenarProdutos(produtos)}
                titulo={`Produtos de ${vendedor.nome_comercial}`}
              />
            )}

          </section>

        </div>
      </main>

      <Rodape />
    </div>
  );
}