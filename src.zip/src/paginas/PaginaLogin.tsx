/**
 * ========================================
 * PÁGINA LOGIN — Autenticação de utilizadores
 * ========================================
 * "Criar conta" redireciona para /anunciar.
 */

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, LogIn, UserPlus, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contextos/AuthContexto';

export default function PaginaLogin() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { login, autenticado } = useAuth();

  const [modo, setModo] = useState<'login' | 'recuperar'>('login');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);

  if (autenticado) {
    navigate('/dashboard');
    return null;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCarregando(true);
    const sucesso = await login(email, senha);
    setCarregando(false);
    if (sucesso) {
      toast({ title: 'Login efetuado com sucesso!' });
      navigate('/dashboard');
    } else {
      toast({ title: 'Erro ao entrar', variant: 'destructive' });
    }
  };

  const handleRecuperar = async (e: React.FormEvent) => {
    e.preventDefault();
    setCarregando(true);
    setTimeout(() => {
      setCarregando(false);
      toast({ title: 'Email enviado!', description: 'Verifique a sua caixa de entrada.' });
      setModo('login');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b-2 border-border bg-green-800">
        <div className="container flex items-center h-14 md:h-16">
          <Link to="/" className="flex items-center gap-2 text-white hover:text-primary transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="font-titulo text-xl font-bold text-white hover:text-primary transition-colors">ANGROLINK</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="font-titulo text-2xl md:text-3xl font-bold text-foreground">
              {modo === 'login' ? 'Entrar na conta' : 'Recuperar senha'}
            </h1>
            <p className="font-corpo text-sm text-muted-foreground mt-2">
              {modo === 'login'
                ? 'Acede à tua conta de vendedor ou comprador'
                : 'Insere o teu email para receber o link de recuperação'}
            </p>
            {modo === 'login' && (
              <div className="mt-3 p-3 border border-border bg-muted/30 rounded-md">
                <p className="font-corpo text-xs text-muted-foreground">
                  <strong>Contas de teste:</strong><br />
                  admin@angrolink.ao · vendedor@angrolink.ao · cliente@angrolink.ao
                </p>
              </div>
            )}
          </div>

          <div className="border-2 border-border bg-card p-6 md:p-8 rounded-md">
            {modo === 'login' && (
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="font-corpo text-sm font-medium">Email</Label>
                  <Input id="email" type="email" placeholder="exemplo@email.com" value={email}
                    onChange={e => setEmail(e.target.value)} required className="border-2 border-border" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="senha" className="font-corpo text-sm font-medium">Senha</Label>
                  <div className="relative">
                    <Input id="senha" type={mostrarSenha ? 'text' : 'password'} placeholder="••••••••" value={senha}
                      onChange={e => setSenha(e.target.value)} required className="border-2 border-border pr-10" />
                    <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {mostrarSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <button type="button" onClick={() => setModo('recuperar')}
                    className="font-corpo text-xs text-primary hover:underline">Esqueceste a senha?</button>
                </div>

                <Button type="submit" disabled={carregando} className="w-full font-corpo font-semibold">
                  <LogIn className="w-4 h-4 mr-2" />
                  {carregando ? 'A entrar...' : 'Entrar'}
                </Button>

                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t-2 border-border" /></div>
                  <div className="relative flex justify-center text-xs"><span className="bg-card px-3 text-muted-foreground font-corpo">ou</span></div>
                </div>

                <Button type="button" variant="outline" onClick={() => navigate('/anunciar')} className="w-full font-corpo border-2">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Criar conta
                </Button>
              </form>
            )}

            {modo === 'recuperar' && (
              <form onSubmit={handleRecuperar} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email-recuperar" className="font-corpo text-sm font-medium">Email</Label>
                  <Input id="email-recuperar" type="email" placeholder="exemplo@email.com" value={email}
                    onChange={e => setEmail(e.target.value)} required className="border-2 border-border" />
                </div>
                <Button type="submit" disabled={carregando} className="w-full font-corpo font-semibold">
                  {carregando ? 'A enviar...' : 'Enviar link de recuperação'}
                </Button>
                <button type="button" onClick={() => setModo('login')}
                  className="w-full text-center font-corpo text-sm text-primary hover:underline mt-2">Voltar ao login</button>
              </form>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
