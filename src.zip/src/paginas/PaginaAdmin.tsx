/**
 * ========================================
 * ÁREA ADMIN — Painel de Gestão
 * ========================================
 * Dashboard com métricas básicas.
 * Gestão de vendedores e produtos.
 * Na Fase 1: login simples e dados mock.
 * TODO: Conectar ao backend real.
 */

import { useState } from 'react';
import { ShieldCheck, Users, Package, MapPin, Star, Eye, EyeOff } from 'lucide-react';
import Cabecalho from '@/componentes/Cabecalho';
import { VENDEDORES_MOCK, PRODUTOS_MOCK } from '@/dados/mock';
import { Vendedor } from '@/tipos';

/**
 * Componente de login simples para acesso ao admin.
 * ATENÇÃO: Login temporário — será substituído por autenticação real.
 */
function LoginAdmin({ onLogin }: { onLogin: () => void }) {
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [erro, setErro] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Senha temporária apenas para demonstração
    // TODO: Substituir por autenticação real com backend
    if (senha === 'angrolink2026') {
      onLogin();
    } else {
      setErro('Senha incorreta');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-sm p-6 border-2 border-border">
        <h1 className="font-titulo text-xl mb-4 text-center">Admin ANGROLINK</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type={mostrarSenha ? 'text' : 'password'}
              value={senha}
              onChange={e => { setSenha(e.target.value); setErro(''); }}
              placeholder="Senha de acesso"
              className="w-full border-2 border-border bg-background text-foreground font-corpo text-sm px-3 py-3 pr-10 focus:outline-none focus:border-primary"
            />
            <button
              type="button"
              onClick={() => setMostrarSenha(!mostrarSenha)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            >
              {mostrarSenha ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {erro && <p className="font-corpo text-xs text-destructive">{erro}</p>}
          <button type="submit" className="btn-whatsapp w-full font-titulo border-2 border-foreground">
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}

/**
 * Painel principal do admin com dashboard e gestão.
 */
export default function PaginaAdmin() {
  const [autenticado, setAutenticado] = useState(false);
  const [abaAtiva, setAbaAtiva] = useState<'dashboard' | 'vendedores'>('dashboard');

  if (!autenticado) {
    return <LoginAdmin onLogin={() => setAutenticado(true)} />;
  }

  // Métricas do dashboard
  const totalVendedores = VENDEDORES_MOCK.length;
  const totalProdutos = PRODUTOS_MOCK.length;
  const produtosDestaque = PRODUTOS_MOCK.filter(p => p.destaque).length;
  const vendedoresVerificados = VENDEDORES_MOCK.filter(v => v.verificado).length;

  // Produtos por município
  const porMunicipio = PRODUTOS_MOCK.reduce<Record<string, number>>((acc, p) => {
    acc[p.municipio] = (acc[p.municipio] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="min-h-screen flex flex-col">
      <Cabecalho />

      <main className="flex-1">
        <div className="container py-6">
          <h1 className="font-titulo text-2xl mb-6">Painel de Administração</h1>

          {/* Abas */}
          <div className="flex border-b-2 border-border mb-6">
            <button
              onClick={() => setAbaAtiva('dashboard')}
              className={`font-titulo text-sm px-4 py-2 border-b-2 -mb-[2px] transition-colors ${
                abaAtiva === 'dashboard' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setAbaAtiva('vendedores')}
              className={`font-titulo text-sm px-4 py-2 border-b-2 -mb-[2px] transition-colors ${
                abaAtiva === 'vendedores' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              Vendedores
            </button>
          </div>

          {/* ===== DASHBOARD ===== */}
          {abaAtiva === 'dashboard' && (
            <div className="space-y-6">
              {/* Cards de métricas */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <MetricaCard icone={Users} rotulo="Total Vendedores" valor={totalVendedores} />
                <MetricaCard icone={Package} rotulo="Total Produtos" valor={totalProdutos} />
                <MetricaCard icone={Star} rotulo="Em Destaque" valor={produtosDestaque} />
                <MetricaCard icone={ShieldCheck} rotulo="Verificados" valor={vendedoresVerificados} />
              </div>

              {/* Produtos por município */}
              <div className="border-2 border-border p-4">
                <h3 className="font-titulo text-sm mb-3">Produtos por Município</h3>
                <div className="space-y-2">
                  {Object.entries(porMunicipio).map(([municipio, total]) => (
                    <div key={municipio} className="flex items-center justify-between">
                      <span className="font-corpo text-sm flex items-center gap-1">
                        <MapPin size={14} className="text-muted-foreground" />
                        {municipio}
                      </span>
                      <span className="font-titulo text-sm">{total}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ===== GESTÃO DE VENDEDORES ===== */}
          {abaAtiva === 'vendedores' && (
            <div className="space-y-3">
              {VENDEDORES_MOCK.map(vendedor => (
                <VendedorLinha key={vendedor.id} vendedor={vendedor} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

/** Card de métrica individual */
function MetricaCard({ icone: Icone, rotulo, valor }: { icone: React.ComponentType<any>; rotulo: string; valor: number }) {
  return (
    <div className="border-2 border-border p-4">
      <Icone size={20} className="text-primary mb-2" />
      <p className="font-titulo text-2xl">{valor}</p>
      <p className="font-corpo text-xs text-muted-foreground">{rotulo}</p>
    </div>
  );
}

/** Linha de vendedor na lista de gestão */
function VendedorLinha({ vendedor }: { vendedor: Vendedor }) {
  return (
    <div className="border-2 border-border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
      <div>
        <div className="flex items-center gap-2">
          <span className="font-titulo text-sm">{vendedor.nome_comercial}</span>
          {vendedor.verificado && (
            <span className="selo-verificado">
              <ShieldCheck size={10} />
            </span>
          )}
          <span className={`font-corpo text-xs px-2 py-0.5 border ${
            vendedor.status === 'ativo' ? 'border-primary text-primary' :
            vendedor.status === 'pendente' ? 'border-secondary text-secondary-foreground' :
            'border-destructive text-destructive'
          }`}>
            {vendedor.status}
          </span>
        </div>
        <p className="font-corpo text-xs text-muted-foreground mt-0.5">
          {vendedor.municipio} · {vendedor.tipo_vendedor} · Plano: {vendedor.plano}
        </p>
      </div>
      <div className="flex gap-2">
        {/* Botões de ação — funcionalidade será conectada ao backend */}
        <button className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-primary hover:text-primary transition-colors">
          Editar
        </button>
        <button className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-destructive hover:text-destructive transition-colors">
          Suspender
        </button>
      </div>
    </div>
  );
}
