import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { MessageCircle, ShieldCheck, ArrowLeft } from 'lucide-react';

import Cabecalho from '@/componentes/Cabecalho';
import Rodape from '@/componentes/Rodape';
import ListaProdutos from '@/componentes/ListaProdutos';

import { obterVendedorPorId, gerarLinkWhatsApp } from '@/dados/mock';
import { obterImagemProduto } from '@/dados/imagens';

// 🔥 API
import {
  fetchProdutoPorId,
  fetchProdutosRelacionados
} from '@/services/api';

// 🔥 fallback controlado
import { PRODUTOS_MOCK } from '@/dados/mock';

import { Produto } from '@/tipos';

export default function PaginaProduto() {
  const { id } = useParams<{ id: string }>();

  const [produto, setProduto] = useState<Produto | null>(null);
  const [relacionados, setRelacionados] = useState<Produto[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function carregarProduto() {
      console.log("ID do produto recebido:", id);

      if (!id) return;

      setLoading(true);

      let data: Produto | null = null;

      // =============================
      // 🔥 1. TENTAR SUPABASE
      // =============================
      try {
        data = await fetchProdutoPorId(id);
      } catch (e) {
        console.warn("Erro ao buscar no Supabase:", e);
      }

      // =============================
      // 🔥 2. FALLBACK CONTROLADO
      // =============================
      if (!data && id.startsWith("p")) {
        console.warn("A usar fallback mock para ID:", id);
        data = PRODUTOS_MOCK.find(p => p.id === id) || null;
      }

      // =============================
      // 🔥 3. NÃO ENCONTRADO
      // =============================
      if (!data) {
        console.warn("Produto não encontrado:", id);
        setProduto(null);
        setRelacionados([]);
        setLoading(false);
        return;
      }

      setProduto(data);

      // =============================
      // 🔥 4. RELACIONADOS (CORRIGIDO)
      // =============================
      let relacionadosData: Produto[] = [];

      try {
        const categoriaId =
          (data as any).categoria_id ||
          (data as any).categoria?.id;

        if (categoriaId && data.id.includes('-')) {
          relacionadosData = await fetchProdutosRelacionados(
            categoriaId,
            data.id
          );
        }
      } catch (e) {
        console.warn("Erro ao buscar relacionados:", e);
      }

      // =============================
      // 🔥 5. FALLBACK RELACIONADOS
      // =============================
      if (
        relacionadosData.length === 0 &&
        data.id.startsWith("p")
      ) {
        console.warn("Fallback relacionados (mock)");

        relacionadosData = PRODUTOS_MOCK
          .filter(p =>
            p.categoria === (data as any).categoria &&
            p.id !== data.id &&
            p.disponivel
          )
          .slice(0, 4);
      }

      setRelacionados(relacionadosData);
      setLoading(false);
    }

    carregarProduto();
  }, [id]);

  // =============================
  // LOADING
  // =============================
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center">
          <p className="font-corpo text-muted-foreground">
            A carregar produto...
          </p>
        </main>
        <Rodape />
      </div>
    );
  }

  // =============================
  // NÃO ENCONTRADO
  // =============================
  if (!produto) {
    return (
      <div className="min-h-screen flex flex-col">
        <Cabecalho />
        <main className="flex-1 flex items-center justify-center">
          <p className="font-corpo text-muted-foreground">
            Produto não encontrado.
          </p>
        </main>
        <Rodape />
      </div>
    );
  }

  // =============================
  // 🔥 VENDEDOR (REAL > MOCK)
  // =============================
  const vendedor =
    (produto as any).vendedor ??
    (produto.vendedor_id
      ? obterVendedorPorId(produto.vendedor_id)
      : null);

  const imagem = obterImagemProduto(produto.id) || '/placeholder.png';

  const precoFormatado = new Intl.NumberFormat('pt-AO').format(
    produto.preco_aproximado || 0
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Cabecalho />

      <main className="flex-1">
        <div className="container py-4">

          {/* Voltar */}
          <Link
            to="/pesquisa"
            className="inline-flex items-center gap-1 font-corpo text-sm text-muted-foreground hover:text-primary mb-4"
          >
            <ArrowLeft size={16} />
            Voltar aos resultados
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* IMAGEM */}
            <div>
              <div className="border-2 border-border overflow-hidden aspect-square">
                <img
                  src={imagem}
                  alt={produto.nome_produto}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/placeholder.png';
                  }}
                />
              </div>
            </div>

            {/* INFO */}
            <div className="space-y-4">
              <h1 className="font-titulo text-2xl md:text-3xl">
                {produto.nome_produto}
              </h1>

              <p className="font-titulo text-3xl text-primary">
                {precoFormatado} Kz
                <span className="text-base font-corpo text-muted-foreground ml-2">
                  / {produto.unidade || '-'}
                </span>
              </p>

              {/* Disponibilidade */}
              <div className="flex items-center gap-2">
                <span className={`inline-block w-2.5 h-2.5 ${produto.disponivel ? 'bg-primary' : 'bg-destructive'}`} />
                <span className="font-corpo text-sm">
                  {produto.disponivel ? 'Disponível' : 'Indisponível'}
                </span>
              </div>

              {/* Descrição */}
              <p className="font-corpo text-sm text-muted-foreground">
                {produto.descricao || 'Sem descrição'}
              </p>

              {/* Localização */}
              <p className="font-corpo text-sm text-muted-foreground">
                📍 {produto.municipio}, {produto.provincia}
              </p>

              {/* Vendedor */}
              {vendedor && (
                <div className="border-2 border-border p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Link
                      to={`/vendedor/${vendedor.id}`}
                      className="font-titulo text-sm hover:text-primary"
                    >
                      {vendedor.nome_comercial}
                    </Link>

                    {vendedor.verificado && (
                      <span className="selo-verificado">
                        <ShieldCheck size={12} />
                        Verificado
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* WhatsApp */}
              {vendedor && (
                <a
                  href={gerarLinkWhatsApp(
                    vendedor.telefone_whatsapp,
                    produto.nome_produto
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-whatsapp w-full flex items-center justify-center gap-2 text-lg border-2 border-foreground"
                >
                  <MessageCircle size={22} />
                  Contactar no WhatsApp
                </a>
              )}
            </div>
          </div>

          {/* RELACIONADOS */}
          {relacionados.length > 0 && (
            <section className="mt-10 pt-6 border-t-2 border-border">
              <ListaProdutos
                produtos={relacionados}
                titulo="Produtos Relacionados"
              />
            </section>
          )}

        </div>
      </main>

      <Rodape />
    </div>
  );
}