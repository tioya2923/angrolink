/**
 * ========================================
 * PÁGINA INICIAL
 * ========================================
 * - Busca TODOS os produtos (sem filtro)
 * - Destaques globais
 * - Filtros só aplicados quando utilizador escolhe
 */

import { Link } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";

import Cabecalho from "@/componentes/Cabecalho";
import Rodape from "@/componentes/Rodape";
import SeletorMunicipio from "@/componentes/SeletorMunicipio";
import SeletorTipoComprador from "@/componentes/SeletorTipoComprador";
import BarraPesquisa from "@/componentes/BarraPesquisa";
import GrelhaCategoria from "@/componentes/GrelhaCategoria";
import ListaProdutos from "@/componentes/ListaProdutos";

import { useAuth } from "@/contextos/AuthContexto";
import { useMunicipio } from "@/contextos/MunicipioContexto";

import { fetchProdutos } from "@/services/api";
import { Produto } from "@/tipos";

export default function PaginaInicial() {
  const { municipioId, municipioNome } = useMunicipio();
  const { tipoComprador } = useAuth();

  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  /**
   * ===============================
   * FETCH (SEM FILTRO 🔥)
   * ===============================
   */

  useEffect(() => {
    async function carregar() {
      try {
        setLoading(true);
        setErro(null);

        const data = await fetchProdutos();

        // 🔥 proteção
        setProdutos(Array.isArray(data) ? data : []);
      } catch {
        setErro("Erro ao carregar produtos");
        setProdutos([]);
      } finally {
        setLoading(false);
      }
    }

    carregar();
  }, []);

  /**
   * ===============================
   * FILTRAR POR TIPO
   * ===============================
   */

  const produtosVisiveis = produtos.filter((p) => {
    if (tipoComprador === "casa") {
      return p.tipo_venda === "retalho" || p.tipo_venda === "ambos";
    }

    if (tipoComprador === "negocio") {
      return p.tipo_venda === "grosso" || p.tipo_venda === "ambos";
    }

    return true;
  });

  /**
   * ===============================
   * FILTRO POR MUNICÍPIO
   * ===============================
   */

  const produtosFiltrados = municipioId
    ? produtosVisiveis.filter(
        (p) =>
          p.municipio?.toLowerCase().trim() ===
          municipioNome?.toLowerCase().trim()
      )
    : produtosVisiveis;

  /**
   * ===============================
   * DESTAQUES
   * ===============================
   */

  const produtosDestaque = produtosVisiveis.filter(
    (p) => p.destaque && p.disponivel
  );

  /**
   * ===============================
   * RECENTES
   * ===============================
   */

  const baseRecentes = municipioId ? produtosFiltrados : produtosVisiveis;

  const produtosRecentes = [...baseRecentes]
    .sort(
      (a, b) =>
        new Date(b.criado_em).getTime() -
        new Date(a.criado_em).getTime()
    )
    .slice(0, 8);

  /**
   * ===============================
   * SECÇÕES
   * ===============================
   */

  const produtosGrosso =
    tipoComprador === "casa"
      ? []
      : produtosFiltrados
          .filter(
            (p) =>
              p.disponivel &&
              (p.tipo_venda === "grosso" || p.tipo_venda === "ambos")
          )
          .slice(0, 4);

  const produtosRetalho =
    tipoComprador === "negocio"
      ? []
      : produtosFiltrados
          .filter(
            (p) =>
              p.disponivel &&
              (p.tipo_venda === "retalho" || p.tipo_venda === "ambos")
          )
          .slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col">
      <Cabecalho />

      <main className="flex-1">

        {/* BANNER */}
        <section
          className="relative border-b-2 border-border h-[360px] md:h-[500px] bg-cover bg-center flex items-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1500382017468-9049fed747ef')",
          }}
        >
          <div className="relative container text-center text-white space-y-4 ">

            <h1 className="font-titulo text-2xl md:text-4xl ">
              Encontre produtos agrícolas em Angola
            </h1>

            <p className="font-corpo text-sm md:text-base text-white/90">
              Selecione o seu município e tipo de compra para ver os produtos certos para si.
            </p>

            <div className="max-w-2xl mx-auto space-y-3">
              <SeletorMunicipio />

              <div className="flex justify-center">
                <SeletorTipoComprador />
              </div>

              <BarraPesquisa />
            </div>

          </div>
        </section>

        {/* CATEGORIAS */}
        <section className="py-6 md:py-8">
          <div className="container">
            <h2 className="font-titulo text-lg md:text-xl mb-4">
              Categorias
            </h2>
            <GrelhaCategoria />
          </div>
        </section>

        {/* LOADING / ERRO */}
        {loading && (
          <div className="container py-6">
            <p>A carregar produtos...</p>
          </div>
        )}

        {erro && (
          <div className="container py-6">
            <p>{erro}</p>
          </div>
        )}

        {!loading && !erro && (
          <>
            {/* DESTAQUES */}
            <section className="secao-destaque py-6 md:py-8 border-y-2 border-border">
              <div className="container">
                <ListaProdutos
                  produtos={produtosDestaque}
                  titulo="Produtos em Destaque"
                />
              </div>
            </section>

            {/* GROSSO */}
            {produtosGrosso.length > 0 && (
              <section className="py-6 md:py-8 border-b-2 border-border">
                <div className="container">
                  <h2 className="font-titulo text-lg md:text-xl mb-1">
                    📦 Comprar por Grosso
                  </h2>
                  <ListaProdutos produtos={produtosGrosso} />
                </div>
              </section>
            )}

            {/* RETALHO */}
            {produtosRetalho.length > 0 && (
              <section className="py-6 md:py-8 border-b-2 border-border">
                <div className="container">
                  <h2 className="font-titulo text-lg md:text-xl mb-1">
                    🛒 Comprar por Retalho
                  </h2>
                  <ListaProdutos produtos={produtosRetalho} />
                </div>
              </section>
            )}

            {/* RECENTES */}
            <section className="py-6 md:py-8">
              <div className="container">
                <ListaProdutos
                  produtos={produtosRecentes}
                  titulo="Novos Produtos"
                />
              </div>
            </section>
          </>
        )}

      </main>

      {/* BOTÃO */}
      <Link
        to="/anunciar"
        className="fixed bottom-4 right-4 z-40 btn-whatsapp flex items-center gap-2 font-titulo text-sm px-5 py-3 border-2 border-foreground"
      >
        <MessageCircle size={18} />
        Quero Anunciar
      </Link>

      <Rodape />
    </div>
  );
}