/**
 * ========================================
 * LAYOUT DASHBOARD — Estrutura partilhada
 * ========================================
 * Menu lateral + conteúdo principal.
 * Adapta-se ao tipo de utilizador.
 */

import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, PlusCircle, MessageSquare, BarChart3,
  UserCircle, Heart, Clock, Sparkles, Settings, Users, ShieldCheck,
  LogOut, Menu, X, ArrowLeft, Share2
} from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { PapelUtilizador } from '@/tipos';

/** Item do menu lateral */
interface ItemMenu {
  rotulo: string;
  icone: React.ComponentType<any>;
  caminho: string;
}

/** Menus por tipo de utilizador */
const MENUS: Record<PapelUtilizador, ItemMenu[]> = {
  admin: [
    { rotulo: 'Dashboard', icone: LayoutDashboard, caminho: '/dashboard' },
    { rotulo: 'Vendedores', icone: Users, caminho: '/dashboard/vendedores' },
    { rotulo: 'Pedidos', icone: UserCircle, caminho: '/dashboard/pedidos-vendedores' },
    { rotulo: 'Utilizadores', icone: ShieldCheck, caminho: '/dashboard/utilizadores' },
    { rotulo: 'Produtos', icone: Package, caminho: '/dashboard/produtos' },
  ],
  vendedor: [
    { rotulo: 'Dashboard', icone: LayoutDashboard, caminho: '/dashboard' },
    { rotulo: 'Meus Produtos', icone: Package, caminho: '/dashboard/produtos' },
    { rotulo: 'Adicionar Produto', icone: PlusCircle, caminho: '/dashboard/adicionar' },
    { rotulo: 'Contactos', icone: MessageSquare, caminho: '/dashboard/contactos' },
    { rotulo: 'Estatísticas', icone: BarChart3, caminho: '/dashboard/estatisticas' },
    { rotulo: 'Perfil', icone: UserCircle, caminho: '/dashboard/perfil' },
  ],
  cliente: [
    { rotulo: 'Dashboard', icone: LayoutDashboard, caminho: '/dashboard' },
    { rotulo: 'Favoritos', icone: Heart, caminho: '/dashboard/favoritos' },
    { rotulo: 'Histórico', icone: Clock, caminho: '/dashboard/historico' },
    { rotulo: 'Recomendações', icone: Sparkles, caminho: '/dashboard/recomendacoes' },
    { rotulo: 'Definições', icone: Settings, caminho: '/dashboard/definicoes' },
  ],
};

interface Props {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: Props) {
  const { utilizador, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [menuAberto, setMenuAberto] = useState(false);

  if (!utilizador) return null;

  const menu = MENUS[utilizador.papel];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Barra superior mobile */}
      <header className="border-b-2 border-border bg-background sticky top-0 z-50">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMenuAberto(!menuAberto)}
              className="lg:hidden text-foreground"
            >
              {menuAberto ? <X size={20} /> : <Menu size={20} />}
            </button>
            <Link to="/" className="font-titulo text-lg font-bold tracking-tight text-foreground">
              ANGROLINK
            </Link>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-corpo text-xs text-muted-foreground hidden sm:block">
              {utilizador.nome}
            </span>
            <button
              onClick={handleLogout}
              className="text-muted-foreground hover:text-destructive transition-colors"
              title="Sair"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Menu lateral — Desktop */}
        <aside className="hidden lg:flex flex-col w-56 border-r-2 border-border bg-background shrink-0">
          <nav className="flex-1 py-4">
            {menu.map(item => {
              const ativo = location.pathname === item.caminho;
              return (
                <Link
                  key={item.caminho}
                  to={item.caminho}
                  className={`flex items-center gap-3 px-4 py-2.5 font-corpo text-sm transition-colors ${
                    ativo
                      ? 'bg-primary/10 text-primary border-r-2 border-primary font-medium'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <item.icone size={18} />
                  {item.rotulo}
                </Link>
              );
            })}
          </nav>
          <div className="border-t-2 border-border p-4">
            <Link
              to="/"
              className="flex items-center gap-2 font-corpo text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft size={14} />
              Voltar ao site
            </Link>
          </div>
        </aside>

        {/* Menu lateral — Mobile (overlay) */}
        {menuAberto && (
          <div className="lg:hidden fixed inset-0 z-40 flex">
            <div className="w-64 bg-background border-r-2 border-border flex flex-col shadow-lg">
              <nav className="flex-1 py-4">
                {menu.map(item => {
                  const ativo = location.pathname === item.caminho;
                  return (
                    <Link
                      key={item.caminho}
                      to={item.caminho}
                      onClick={() => setMenuAberto(false)}
                      className={`flex items-center gap-3 px-4 py-3 font-corpo text-sm transition-colors ${
                        ativo
                          ? 'bg-primary/10 text-primary font-medium'
                          : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <item.icone size={18} />
                      {item.rotulo}
                    </Link>
                  );
                })}
              </nav>
              <div className="border-t-2 border-border p-4">
                <Link
                  to="/"
                  onClick={() => setMenuAberto(false)}
                  className="flex items-center gap-2 font-corpo text-xs text-muted-foreground hover:text-foreground"
                >
                  <ArrowLeft size={14} />
                  Voltar ao site
                </Link>
              </div>
            </div>
            {/* Overlay */}
            <div className="flex-1 bg-foreground/20" onClick={() => setMenuAberto(false)} />
          </div>
        )}

        {/* Conteúdo principal */}
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
