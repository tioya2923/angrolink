/**
 * ========================================
 * ROUTER DASHBOARD — Distribui por papel
 * ========================================
 * Mostra o dashboard correto conforme o tipo de utilizador.
 */

import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/contextos/AuthContexto';
import DashboardLayout from './DashboardLayout';

// Admin
import AdminResumo from './admin/AdminResumo';
import AdminVendedores from './admin/AdminVendedores';
import AdminProdutos from './admin/AdminProdutos';
import AdminUtilizadores from './admin/AdminUtilizadores';
import AdminPedidosVendedores from './admin/AdminPedidosVendedores';

// Cliente
import ClienteResumo from './cliente/ClienteResumo';
import ClienteFavoritos from './cliente/ClienteFavoritos';
import ClienteHistorico from './cliente/ClienteHistorico';
import ClienteRecomendacoes from './cliente/ClienteRecomendacoes';
import ClienteDefinicoes from './cliente/ClienteDefinicoes';

// Vendedor
import VendedorResumo from './vendedor/VendedorResumo';
import VendedorProdutos from './vendedor/VendedorProdutos';
import VendedorAdicionarProduto from './vendedor/VendedorAdicionarProduto';
import VendedorContactos from './vendedor/VendedorContactos';
import VendedorEstatisticas from './vendedor/VendedorEstatisticas';
import VendedorPerfil from './vendedor/VendedorPerfil';

export default function DashboardRouter() {
  const { utilizador, autenticado } = useAuth();

  if (!autenticado || !utilizador) {
    return <Navigate to="/login" replace />;
  }

  return (
    <DashboardLayout>
      <Routes>
        {/* ===== ADMIN ===== */}
        {utilizador.papel === 'admin' && (
          <>
            <Route index element={<AdminResumo />} />
            <Route path="vendedores" element={<AdminVendedores />} />
            <Route path="pedidos-vendedores" element={<AdminPedidosVendedores />} />
            <Route path="utilizadores" element={<AdminUtilizadores />} />
            <Route path="produtos" element={<AdminProdutos />} />
          </>
        )}

        {/* ===== VENDEDOR ===== */}
        {utilizador.papel === 'vendedor' && (
          <>
            <Route index element={<VendedorResumo />} />
            <Route path="produtos" element={<VendedorProdutos />} />
            <Route path="adicionar" element={<VendedorAdicionarProduto />} />
            <Route path="contactos" element={<VendedorContactos />} />
            <Route path="estatisticas" element={<VendedorEstatisticas />} />
            <Route path="perfil" element={<VendedorPerfil />} />
          </>
        )}

        {/* ===== CLIENTE ===== */}
        {utilizador.papel === 'cliente' && (
          <>
            <Route index element={<ClienteResumo />} />
            <Route path="favoritos" element={<ClienteFavoritos />} />
            <Route path="historico" element={<ClienteHistorico />} />
            <Route path="recomendacoes" element={<ClienteRecomendacoes />} />
            <Route path="definicoes" element={<ClienteDefinicoes />} />
          </>
        )}

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </DashboardLayout>
  );
}
