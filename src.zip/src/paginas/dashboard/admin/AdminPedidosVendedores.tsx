/**
 * Admin — Pedidos de Vendedores (aprovação completa)
 * Lista vendedores pendentes com ações: aprovar, rejeitar, suspender, eliminar.
 * Usa StatusVendedorAprovacao: pendente | aprovado | rejeitado | suspenso
 */

import { useState } from 'react';
import { CheckCircle, XCircle, Ban, Trash2, MapPin, Calendar, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { TIPOS_VENDEDOR } from '@/dados/constantes';
import { StatusVendedorAprovacao } from '@/tipos';

interface PedidoVendedor {
  id: string;
  nome_comercial: string;
  nome_responsavel: string;
  tipo_vendedor: string;
  provincia: string;
  municipio: string;
  mercado_bairro: string;
  telefone: string;
  email: string;
  descricao: string;
  data_registo: string;
  estado: StatusVendedorAprovacao;
  ano_inicio?: string;
  entrega_disponivel?: boolean;
}

const PEDIDOS_MOCK: PedidoVendedor[] = [
  {
    id: 'pv1', nome_comercial: 'Cereais do Huambo', nome_responsavel: 'António Silva',
    tipo_vendedor: 'distribuidor_grosso', provincia: 'Huambo', municipio: 'Huambo',
    mercado_bairro: 'Mercado Central', telefone: '244934567890', email: 'antonio@cereais.ao',
    descricao: 'Venda por grosso de milho, feijão e soja direto do campo.',
    data_registo: '2026-03-10', estado: 'pendente', entrega_disponivel: true,
  },
  {
    id: 'pv2', nome_comercial: 'Frutas do Bengo', nome_responsavel: 'Teresa Manuel',
    tipo_vendedor: 'produtor', provincia: 'Bengo', municipio: 'Bengo',
    mercado_bairro: 'Fazenda Kikuxi', telefone: '244967890123', email: 'teresa@frutas.ao',
    descricao: 'Produção de manga, banana e abacate. Entrega em Luanda.',
    data_registo: '2026-03-11', estado: 'pendente', ano_inicio: '2018',
  },
  {
    id: 'pv3', nome_comercial: 'Mini-Mercado Boa Vida', nome_responsavel: 'José Domingos',
    tipo_vendedor: 'loja', provincia: 'Luanda', municipio: 'Belas',
    mercado_bairro: 'Talatona', telefone: '244978901234', email: 'jose@boavida.ao',
    descricao: 'Loja de bairro com produtos frescos e mercearia.',
    data_registo: '2026-03-12', estado: 'pendente',
  },
  {
    id: 'pv4', nome_comercial: 'Quinta Verde', nome_responsavel: 'Marta Sousa',
    tipo_vendedor: 'quinta', provincia: 'Huila', municipio: 'Lubango',
    mercado_bairro: 'Zona Rural', telefone: '244989012345', email: 'marta@quintaverde.ao',
    descricao: 'Quinta familiar com hortaliças orgânicas e criação de galinhas.',
    data_registo: '2026-03-13', estado: 'pendente', ano_inicio: '2015', entrega_disponivel: false,
  },
];

export default function AdminPedidosVendedores() {
  const { toast } = useToast();
  const [pedidos, setPedidos] = useState<PedidoVendedor[]>([...PEDIDOS_MOCK]);
  const [detalheAberto, setDetalheAberto] = useState<string | null>(null);
  const [filtroEstado, setFiltroEstado] = useState<StatusVendedorAprovacao | 'todos'>('pendente');

  const alterarEstado = (id: string, estado: StatusVendedorAprovacao) => {
    setPedidos(prev => prev.map(p => p.id === id ? { ...p, estado } : p));
    const msgs: Record<StatusVendedorAprovacao, { title: string; desc: string }> = {
      aprovado: { title: 'Vendedor aprovado!', desc: 'O vendedor pode agora publicar produtos.' },
      rejeitado: { title: 'Vendedor rejeitado', desc: 'O vendedor não poderá publicar produtos.' },
      suspenso: { title: 'Vendedor suspenso', desc: 'A conta foi temporariamente suspensa.' },
      pendente: { title: 'Estado revertido', desc: 'Voltou a pendente.' },
    };
    toast({ title: msgs[estado].title, description: msgs[estado].desc });
  };

  const eliminarVendedor = (id: string) => {
    setPedidos(prev => prev.filter(p => p.id !== id));
    toast({ title: 'Vendedor eliminado', description: 'Conta e dados removidos do sistema.', variant: 'destructive' });
  };

  const obterBadgeTipo = (tipo: string) => {
    const tv = TIPOS_VENDEDOR.find(t => t.valor === tipo);
    return tv ? `${tv.icone} ${tv.rotulo}` : tipo;
  };

  const pedidosFiltrados = filtroEstado === 'todos'
    ? pedidos
    : pedidos.filter(p => p.estado === filtroEstado);

  const contadores = {
    pendente: pedidos.filter(p => p.estado === 'pendente').length,
    aprovado: pedidos.filter(p => p.estado === 'aprovado').length,
    rejeitado: pedidos.filter(p => p.estado === 'rejeitado').length,
    suspenso: pedidos.filter(p => p.estado === 'suspenso').length,
  };

  const corEstado: Record<StatusVendedorAprovacao, string> = {
    pendente: 'border-yellow-500/50 bg-yellow-500/5',
    aprovado: 'border-primary/50 bg-primary/5',
    rejeitado: 'border-destructive/50 bg-destructive/5',
    suspenso: 'border-orange-500/50 bg-orange-500/5',
  };

  const badgeEstado: Record<StatusVendedorAprovacao, string> = {
    pendente: 'border-yellow-500 text-yellow-600',
    aprovado: 'border-primary text-primary',
    rejeitado: 'border-destructive text-destructive',
    suspenso: 'border-orange-500 text-orange-600',
  };

  return (
    <div className="space-y-6">
      <h1 className="font-titulo text-2xl font-bold">Pedidos de Vendedores</h1>

      {/* Contadores */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {(Object.entries(contadores) as [StatusVendedorAprovacao, number][]).map(([estado, count]) => (
          <button key={estado} onClick={() => setFiltroEstado(estado)}
            className={`border-2 p-3 rounded-md text-center transition-colors ${
              filtroEstado === estado ? corEstado[estado] + ' border-opacity-100' : 'border-border hover:border-muted-foreground/30'
            }`}>
            <p className="font-titulo text-xl font-bold">{count}</p>
            <p className="font-corpo text-xs text-muted-foreground capitalize">{estado}s</p>
          </button>
        ))}
      </div>

      {/* Filtro */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setFiltroEstado('todos')}
          className={`font-corpo text-xs px-3 py-1.5 border-2 rounded-md transition-colors ${
            filtroEstado === 'todos' ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-muted-foreground'
          }`}>
          Todos ({pedidos.length})
        </button>
        {(Object.entries(contadores) as [StatusVendedorAprovacao, number][]).map(([estado, count]) => (
          <button key={estado} onClick={() => setFiltroEstado(estado)}
            className={`font-corpo text-xs px-3 py-1.5 border-2 rounded-md transition-colors capitalize ${
              filtroEstado === estado ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-muted-foreground'
            }`}>
            {estado} ({count})
          </button>
        ))}
      </div>

      {/* Lista */}
      <div className="space-y-3">
        {pedidosFiltrados.length === 0 && (
          <p className="font-corpo text-sm text-muted-foreground py-8 text-center">
            Nenhum vendedor neste estado.
          </p>
        )}
        {pedidosFiltrados.map(p => (
          <div key={p.id} className={`border-2 ${corEstado[p.estado]} p-4 rounded-md space-y-3`}>
            {/* Cabeçalho */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-titulo text-sm font-medium">{p.nome_comercial}</span>
                <span className="font-corpo text-xs px-2 py-0.5 border border-border text-muted-foreground rounded">
                  {obterBadgeTipo(p.tipo_vendedor)}
                </span>
                <span className={`font-corpo text-xs px-2 py-0.5 border rounded capitalize ${badgeEstado[p.estado]}`}>
                  {p.estado}
                </span>
              </div>
              <button onClick={() => setDetalheAberto(detalheAberto === p.id ? null : p.id)}
                className="flex items-center gap-1 font-corpo text-xs text-primary hover:underline">
                <Eye size={14} />
                {detalheAberto === p.id ? 'Ocultar' : 'Ver detalhes'}
              </button>
            </div>

            {/* Info básica */}
            <div className="font-corpo text-xs text-muted-foreground space-y-0.5">
              <p>Responsável: {p.nome_responsavel}</p>
              <p className="flex items-center gap-1"><MapPin size={12} /> {p.municipio}, {p.provincia} · {p.mercado_bairro}</p>
              <p className="flex items-center gap-1"><Calendar size={12} /> Registado em {p.data_registo}</p>
            </div>

            {/* Detalhes expandidos */}
            {detalheAberto === p.id && (
              <div className="border-t border-border pt-3 space-y-2">
                <p className="font-corpo text-xs"><strong>Email:</strong> {p.email}</p>
                <p className="font-corpo text-xs"><strong>Telefone:</strong> {p.telefone}</p>
                <p className="font-corpo text-xs"><strong>Descrição:</strong> {p.descricao}</p>
                {p.ano_inicio && <p className="font-corpo text-xs"><strong>Ativo desde:</strong> {p.ano_inicio}</p>}
                {p.entrega_disponivel !== undefined && (
                  <p className="font-corpo text-xs"><strong>Entrega:</strong> {p.entrega_disponivel ? 'Sim' : 'Não'}</p>
                )}
              </div>
            )}

            {/* Ações */}
            <div className="flex gap-2 flex-wrap">
              {p.estado !== 'aprovado' && (
                <button onClick={() => alterarEstado(p.id, 'aprovado')}
                  className="flex items-center gap-1 font-corpo text-xs border-2 border-primary text-primary px-3 py-1.5 rounded hover:bg-primary hover:text-primary-foreground transition-colors">
                  <CheckCircle size={14} /> Aprovar
                </button>
              )}
              {p.estado !== 'rejeitado' && (
                <button onClick={() => alterarEstado(p.id, 'rejeitado')}
                  className="flex items-center gap-1 font-corpo text-xs border-2 border-destructive text-destructive px-3 py-1.5 rounded hover:bg-destructive hover:text-destructive-foreground transition-colors">
                  <XCircle size={14} /> Rejeitar
                </button>
              )}
              {p.estado !== 'suspenso' && p.estado !== 'rejeitado' && (
                <button onClick={() => alterarEstado(p.id, 'suspenso')}
                  className="flex items-center gap-1 font-corpo text-xs border-2 border-orange-500 text-orange-600 px-3 py-1.5 rounded hover:bg-orange-500 hover:text-white transition-colors">
                  <Ban size={14} /> Suspender
                </button>
              )}
              <button onClick={() => eliminarVendedor(p.id)}
                className="flex items-center gap-1 font-corpo text-xs border-2 border-destructive/50 text-destructive/70 px-3 py-1.5 rounded hover:bg-destructive hover:text-destructive-foreground transition-colors ml-auto">
                <Trash2 size={14} /> Eliminar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
