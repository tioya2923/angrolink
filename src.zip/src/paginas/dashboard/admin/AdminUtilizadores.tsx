/**
 * Admin — Gestão de Utilizadores
 * Lista todos os utilizadores (clientes, vendedores, admins).
 * Permite eliminar contas com confirmação.
 */

import { useState } from 'react';
import { Trash2, User, ShieldCheck, Store, UserCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { TIPOS_VENDEDOR } from '@/dados/constantes';

interface UtilizadorAdmin {
  id: string;
  nome: string;
  email: string;
  telefone: string;
  tipo_conta: 'admin' | 'cliente' | 'vendedor';
  tipo_vendedor?: string;
  data_registo: string;
  estado: 'ativo' | 'pendente' | 'suspenso' | 'rejeitado';
}

const UTILIZADORES_MOCK: UtilizadorAdmin[] = [
  { id: 'u-admin', nome: 'Administrador', email: 'admin@angrolink.ao', telefone: '244900000000', tipo_conta: 'admin', data_registo: '2025-12-01', estado: 'ativo' },
  { id: 'u-c1', nome: 'Paulo Santos', email: 'cliente@angrolink.ao', telefone: '244911111111', tipo_conta: 'cliente', data_registo: '2026-01-15', estado: 'ativo' },
  { id: 'u-c2', nome: 'Ana Fernandes', email: 'ana@email.ao', telefone: '244922222222', tipo_conta: 'cliente', data_registo: '2026-02-10', estado: 'ativo' },
  { id: 'u-v1', nome: 'Maria Josefa', email: 'vendedor@angrolink.ao', telefone: '244923456789', tipo_conta: 'vendedor', tipo_vendedor: 'produtor', data_registo: '2025-12-15', estado: 'ativo' },
  { id: 'u-v2', nome: 'João Pedro', email: 'joao@avicola.ao', telefone: '244912345678', tipo_conta: 'vendedor', tipo_vendedor: 'produtor', data_registo: '2026-01-10', estado: 'ativo' },
  { id: 'u-v3', nome: 'António Silva', email: 'antonio@cereais.ao', telefone: '244934567890', tipo_conta: 'vendedor', tipo_vendedor: 'distribuidor_grosso', data_registo: '2026-02-20', estado: 'pendente' },
  { id: 'u-v4', nome: 'Ana Luísa', email: 'ana@sumos.ao', telefone: '244945678901', tipo_conta: 'vendedor', tipo_vendedor: 'loja', data_registo: '2026-01-05', estado: 'ativo' },
  { id: 'u-v5', nome: 'Carlos Mendes', email: 'carlos@dist.ao', telefone: '244956789012', tipo_conta: 'vendedor', tipo_vendedor: 'distribuidor_grosso', data_registo: '2026-01-20', estado: 'ativo' },
];

export default function AdminUtilizadores() {
  const { toast } = useToast();
  const [utilizadores, setUtilizadores] = useState<UtilizadorAdmin[]>([...UTILIZADORES_MOCK]);
  const [confirmarEliminar, setConfirmarEliminar] = useState<string | null>(null);
  const [filtroTipo, setFiltroTipo] = useState<string>('todos');

  const eliminarConta = (id: string) => {
    setUtilizadores(prev => prev.filter(u => u.id !== id));
    setConfirmarEliminar(null);
    toast({ title: 'Conta eliminada com sucesso' });
  };

  const obterBadgeTipo = (tipo: string) => {
    const tv = TIPOS_VENDEDOR.find(t => t.valor === tipo);
    return tv ? `${tv.icone} ${tv.rotulo}` : tipo;
  };

  const obterIconeTipo = (tipo: string) => {
    switch (tipo) {
      case 'admin': return <ShieldCheck size={14} className="text-primary" />;
      case 'vendedor': return <Store size={14} className="text-primary" />;
      default: return <User size={14} className="text-muted-foreground" />;
    }
  };

  const estadoCor = (estado: string) => {
    switch (estado) {
      case 'ativo': return 'border-primary text-primary';
      case 'pendente': return 'border-yellow-500 text-yellow-600';
      case 'suspenso': return 'border-destructive text-destructive';
      case 'rejeitado': return 'border-destructive text-destructive';
      default: return 'border-border text-muted-foreground';
    }
  };

  const filtrados = filtroTipo === 'todos'
    ? utilizadores
    : utilizadores.filter(u => u.tipo_conta === filtroTipo);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h1 className="font-titulo text-2xl font-bold">Gestão de Utilizadores</h1>
        <div className="flex items-center gap-2">
          <span className="font-corpo text-xs text-muted-foreground">Filtrar:</span>
          <select
            value={filtroTipo}
            onChange={e => setFiltroTipo(e.target.value)}
            className="font-corpo text-xs border-2 border-border bg-background px-2 py-1.5 focus:outline-none focus:border-primary"
          >
            <option value="todos">Todos ({utilizadores.length})</option>
            <option value="cliente">Clientes ({utilizadores.filter(u => u.tipo_conta === 'cliente').length})</option>
            <option value="vendedor">Vendedores ({utilizadores.filter(u => u.tipo_conta === 'vendedor').length})</option>
            <option value="admin">Admins ({utilizadores.filter(u => u.tipo_conta === 'admin').length})</option>
          </select>
        </div>
      </div>

      <div className="space-y-3">
        {filtrados.map(u => (
          <div key={u.id} className="border-2 border-border p-4 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              {obterIconeTipo(u.tipo_conta)}
              <span className="font-titulo text-sm font-medium">{u.nome}</span>
              <span className={`font-corpo text-xs px-2 py-0.5 border ${estadoCor(u.estado)}`}>
                {u.estado}
              </span>
              <span className="font-corpo text-xs px-2 py-0.5 border border-border text-muted-foreground capitalize">
                {u.tipo_conta}
              </span>
            </div>

            <div className="font-corpo text-xs text-muted-foreground space-y-0.5">
              <p>{u.email} · {u.telefone}</p>
              <p>Registado: {u.data_registo}</p>
              {u.tipo_conta === 'vendedor' && u.tipo_vendedor && (
                <p>Tipo: {obterBadgeTipo(u.tipo_vendedor)}</p>
              )}
            </div>

            <div className="flex gap-2 pt-1">
              {u.tipo_conta !== 'admin' && (
                <>
                  {confirmarEliminar === u.id ? (
                    <div className="flex items-center gap-2">
                      <span className="font-corpo text-xs text-destructive">Tem a certeza? Esta ação não pode ser desfeita.</span>
                      <button
                        onClick={() => eliminarConta(u.id)}
                        className="font-corpo text-xs border-2 border-destructive text-destructive px-3 py-1.5 hover:bg-destructive hover:text-destructive-foreground transition-colors"
                      >
                        Confirmar
                      </button>
                      <button
                        onClick={() => setConfirmarEliminar(null)}
                        className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-foreground transition-colors"
                      >
                        Cancelar
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmarEliminar(u.id)}
                      className="flex items-center gap-1 font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-destructive hover:text-destructive transition-colors"
                    >
                      <Trash2 size={14} /> Eliminar
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
