/**
 * Admin — Gestão de produtos
 * Editar destaque, disponibilidade.
 */

import { useState } from 'react';
import { Star, Eye, EyeOff } from 'lucide-react';
import { PRODUTOS_MOCK, obterVendedorPorId } from '@/dados/mock';
import { Produto } from '@/tipos';
import { useToast } from '@/hooks/use-toast';

export default function AdminProdutos() {
  const { toast } = useToast();
  const [produtos, setProdutos] = useState<Produto[]>([...PRODUTOS_MOCK]);

  const toggleDestaque = (id: string) => {
    setProdutos(prev => prev.map(p => p.id === id ? { ...p, destaque: !p.destaque } : p));
    toast({ title: 'Destaque atualizado' });
  };

  const toggleDisponivel = (id: string) => {
    setProdutos(prev => prev.map(p => p.id === id ? { ...p, disponivel: !p.disponivel } : p));
    toast({ title: 'Disponibilidade atualizada' });
  };

  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Gestão de Produtos</h1>

      <div className="space-y-2">
        {produtos.map(p => {
          const vendedor = obterVendedorPorId(p.vendedor_id);
          return (
            <div key={p.id} className="border-2 border-border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-titulo text-sm">{p.nome_produto}</span>
                  {p.destaque && <Star size={14} className="text-secondary fill-secondary" />}
                  {!p.disponivel && <span className="font-corpo text-xs text-destructive">(indisponível)</span>}
                </div>
                <p className="font-corpo text-xs text-muted-foreground">
                  {vendedor?.nome_comercial} · {p.municipio} · {p.preco_aproximado.toLocaleString()} Kz/{p.unidade}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleDestaque(p.id)}
                  className={`font-corpo text-xs border-2 px-3 py-1.5 transition-colors ${
                    p.destaque ? 'border-secondary text-secondary' : 'border-border hover:border-secondary hover:text-secondary'
                  }`}
                >
                  <Star size={12} className="inline mr-1" />
                  {p.destaque ? 'Remover Destaque' : 'Destacar'}
                </button>
                <button
                  onClick={() => toggleDisponivel(p.id)}
                  className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-primary hover:text-primary transition-colors"
                >
                  {p.disponivel ? <><EyeOff size={12} className="inline mr-1" />Ocultar</> : <><Eye size={12} className="inline mr-1" />Mostrar</>}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
