/**
 * Admin — Dashboard com métricas gerais
 */

import { Users, Package, Star, ShieldCheck, MapPin } from 'lucide-react';
import { VENDEDORES_MOCK, PRODUTOS_MOCK } from '@/dados/mock';

export default function AdminResumo() {
  const totalVendedores = VENDEDORES_MOCK.length;
  const totalProdutos = PRODUTOS_MOCK.length;
  const produtosDestaque = PRODUTOS_MOCK.filter(p => p.destaque).length;
  const vendedoresVerificados = VENDEDORES_MOCK.filter(v => v.verificado).length;

  const porMunicipio = PRODUTOS_MOCK.reduce<Record<string, number>>((acc, p) => {
    acc[p.municipio] = (acc[p.municipio] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <h1 className="font-titulo text-2xl font-bold">Painel de Administração</h1>

      {/* Cards de métricas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <CardMetrica icone={Users} rotulo="Total Vendedores" valor={totalVendedores} />
        <CardMetrica icone={Package} rotulo="Total Produtos" valor={totalProdutos} />
        <CardMetrica icone={Star} rotulo="Em Destaque" valor={produtosDestaque} />
        <CardMetrica icone={ShieldCheck} rotulo="Verificados" valor={vendedoresVerificados} />
      </div>

      {/* Produtos por município */}
      <div className="border-2 border-border p-4">
        <h3 className="font-titulo text-sm mb-3">Produtos por Município</h3>
        <div className="space-y-2">
          {Object.entries(porMunicipio).map(([municipio, total]) => (
            <div key={municipio} className="flex items-center justify-between">
              <span className="font-corpo text-sm flex items-center gap-1">
                <MapPin size={14} className="text-muted-foreground" />
                {municipio}
              </span>
              <span className="font-titulo text-sm">{total}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CardMetrica({ icone: Icone, rotulo, valor }: { icone: React.ComponentType<any>; rotulo: string; valor: number }) {
  return (
    <div className="border-2 border-border p-4">
      <Icone size={20} className="text-primary mb-2" />
      <p className="font-titulo text-2xl">{valor}</p>
      <p className="font-corpo text-xs text-muted-foreground">{rotulo}</p>
    </div>
  );
}
