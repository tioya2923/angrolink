/**
 * Admin — Gestão de vendedores
 * Aprovar, verificar, alterar plano, suspender.
 */

import { useState } from 'react';
import { ShieldCheck, CheckCircle, XCircle, Crown } from 'lucide-react';
import { VENDEDORES_MOCK } from '@/dados/mock';
import { Vendedor, PlanoVendedor, StatusVendedor } from '@/tipos';
import { useToast } from '@/hooks/use-toast';

export default function AdminVendedores() {
  const { toast } = useToast();
  const [vendedores, setVendedores] = useState<Vendedor[]>([...VENDEDORES_MOCK]);

  /** TODO (backend): Substituir por chamada à API */
  const alterarStatus = (id: string, status: StatusVendedor) => {
    setVendedores(prev => prev.map(v => v.id === id ? { ...v, status } : v));
    toast({ title: `Vendedor ${status === 'ativo' ? 'ativado' : status === 'suspenso' ? 'suspenso' : 'pendente'}` });
  };

  const alterarVerificacao = (id: string, verificado: boolean) => {
    setVendedores(prev => prev.map(v => v.id === id ? { ...v, verificado } : v));
    toast({ title: verificado ? 'Vendedor verificado!' : 'Verificação removida' });
  };

  const alterarPlano = (id: string, plano: PlanoVendedor) => {
    setVendedores(prev => prev.map(v => v.id === id ? { ...v, plano } : v));
    toast({ title: `Plano alterado para ${plano}` });
  };

  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Gestão de Vendedores</h1>

      <div className="space-y-3">
        {vendedores.map(v => (
          <div key={v.id} className="border-2 border-border p-4 space-y-3">
            {/* Info */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-titulo text-sm">{v.nome_comercial}</span>
              {v.verificado && (
                <span className="selo-verificado"><ShieldCheck size={10} /></span>
              )}
              <span className={`font-corpo text-xs px-2 py-0.5 border ${
                v.status === 'ativo' ? 'border-primary text-primary' :
                v.status === 'pendente' ? 'border-secondary text-secondary-foreground' :
                'border-destructive text-destructive'
              }`}>
                {v.status}
              </span>
              <span className="font-corpo text-xs px-2 py-0.5 border border-border text-muted-foreground">
                {v.plano}
              </span>
            </div>
            <p className="font-corpo text-xs text-muted-foreground">
              {v.municipio} · {v.tipo_vendedor} · {v.nome_responsavel}
            </p>

            {/* Ações */}
            <div className="flex flex-wrap gap-2">
              {v.status === 'pendente' && (
                <BotaoAcao onClick={() => alterarStatus(v.id, 'ativo')} cor="primary">
                  <CheckCircle size={14} /> Aprovar
                </BotaoAcao>
              )}
              {v.status === 'ativo' && (
                <BotaoAcao onClick={() => alterarStatus(v.id, 'suspenso')} cor="destructive">
                  <XCircle size={14} /> Suspender
                </BotaoAcao>
              )}
              {v.status === 'suspenso' && (
                <BotaoAcao onClick={() => alterarStatus(v.id, 'ativo')} cor="primary">
                  <CheckCircle size={14} /> Reativar
                </BotaoAcao>
              )}
              <BotaoAcao onClick={() => alterarVerificacao(v.id, !v.verificado)} cor="primary">
                <ShieldCheck size={14} /> {v.verificado ? 'Remover Verificação' : 'Verificar'}
              </BotaoAcao>

              {/* Alterar plano */}
              <select
                value={v.plano}
                onChange={e => alterarPlano(v.id, e.target.value as PlanoVendedor)}
                className="font-corpo text-xs border-2 border-border bg-background px-2 py-1.5 focus:outline-none focus:border-primary"
              >
                <option value="gratuito">Gratuito</option>
                <option value="destaque">Destaque</option>
                <option value="premium">Premium</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function BotaoAcao({ children, onClick, cor }: { children: React.ReactNode; onClick: () => void; cor: 'primary' | 'destructive' }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1 font-corpo text-xs border-2 border-border px-3 py-1.5 transition-colors hover:border-${cor} hover:text-${cor}`}
    >
      {children}
    </button>
  );
}
