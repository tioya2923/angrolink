/**
 * Vendedor — Formulário para adicionar produto
 * Subcategorias dinâmicas por categoria + tipo de venda + quantidade mínima + foto de perfil
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { CATEGORIAS, PROVINCIAS, MUNICIPIOS, UNIDADES, TIPOS_VENDA } from '@/dados/constantes';
import { SUBCATEGORIAS } from '@/dados/subcategorias';
import { useToast } from '@/hooks/use-toast';
import { criarProduto, uploadImagemProduto } from '@/services/api';


export default function VendedorAdicionarProduto() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [nome, setNome] = useState('');
  const [categoria, setCategoria] = useState('');
  const [subcategoria, setSubcategoria] = useState('');
  const [preco, setPreco] = useState('');
  const [unidade, setUnidade] = useState('kg');
  const [tipoVenda, setTipoVenda] = useState('retalho');
  const [quantidadeMinima, setQuantidadeMinima] = useState('1');
  const [descricao, setDescricao] = useState('');
  const [disponivel, setDisponivel] = useState(true);
  const [provincia, setProvincia] = useState('');
  const [municipio, setMunicipio] = useState('');
  const [imagemPreview, setImagemPreview] = useState<string | null>(null);

  const municipiosFiltrados = MUNICIPIOS.filter(
    m => m.provincia_id === PROVINCIAS.find(p => p.nome === provincia)?.id
  );

  const subcategoriasFiltradas = categoria ? (SUBCATEGORIAS[categoria] || []) : [];

  const handleCategoriaChange = (val: string) => {
    setCategoria(val);
    setSubcategoria('');
  };

  const handleImagemChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast({ title: 'Imagem demasiado grande', description: 'Tamanho máximo: 500KB', variant: 'destructive' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setImagemPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

    try {
      let imagem_url = '';

      // ⚠️ aqui só tens preview base64 → não estás a guardar ficheiro real
      // (vamos ignorar upload por agora)

      await criarProduto({
        nome_produto: nome,
        descricao,
        categoria_id: categoria,
        preco_aproximado: Number(preco),
        unidade,
        tipo_venda: tipoVenda as 'retalho' | 'grosso' | 'ambos',
        municipio,
        provincia,
        imagem_url,
      });

      toast({
        title: 'Produto publicado!',
        description: 'Agora já está no marketplace 🔥'
      });

      navigate('/pesquisa');

    } catch (err) {
      console.error(err);
      toast({
        title: 'Erro ao criar produto',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="font-titulo text-2xl font-bold">Adicionar Produto</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Nome do produto *</Label>
          <Input value={nome} onChange={e => setNome(e.target.value)} required className="border-2 border-border" placeholder="Ex: Tomate Cereja Fresco" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Categoria *</Label>
            <select value={categoria} onChange={e => handleCategoriaChange(e.target.value)} required className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              <option value="">Selecionar</option>
              {CATEGORIAS.map(c => <option key={c.id} value={c.id}>{c.nome_categoria}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Subcategoria *</Label>
            <select
              value={subcategoria}
              onChange={e => setSubcategoria(e.target.value)}
              required
              disabled={!categoria}
              className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary disabled:opacity-50"
            >
              <option value="">{categoria ? 'Selecionar' : 'Escolha categoria primeiro'}</option>
              {subcategoriasFiltradas.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Preço aproximado (Kz) *</Label>
            <Input type="number" value={preco} onChange={e => setPreco(e.target.value)} required className="border-2 border-border" placeholder="0" />
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Unidade *</Label>
            <select value={unidade} onChange={e => setUnidade(e.target.value)} className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              {UNIDADES.map(u => <option key={u.valor} value={u.valor}>{u.rotulo}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Tipo de venda *</Label>
            <select value={tipoVenda} onChange={e => setTipoVenda(e.target.value)} className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              {TIPOS_VENDA.map(t => <option key={t.valor} value={t.valor}>{t.rotulo}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Quantidade mínima *</Label>
            <Input type="number" value={quantidadeMinima} onChange={e => setQuantidadeMinima(e.target.value)} required min="0.1" step="0.1" className="border-2 border-border" placeholder="1" />
          </div>
        </div>

        <div className="space-y-2">
          <Label className="font-corpo text-sm">Descrição</Label>
          <textarea
            value={descricao}
            onChange={e => setDescricao(e.target.value)}
            rows={3}
            className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary resize-none"
            placeholder="Descreva o seu produto..."
          />
        </div>

        {/* Upload de imagem */}
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Imagem principal</Label>
          <div className="border-2 border-dashed border-border p-4 text-center">
            {imagemPreview ? (
              <div className="space-y-2">
                <img src={imagemPreview} alt="Preview" className="w-32 h-32 object-cover mx-auto" />
                <button type="button" onClick={() => setImagemPreview(null)} className="font-corpo text-xs text-destructive hover:underline">
                  Remover
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="font-corpo text-xs text-muted-foreground">
                  Máximo 500KB · JPG, PNG
                </p>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleImagemChange}
                  className="font-corpo text-xs"
                />
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Província *</Label>
            <select value={provincia} onChange={e => { setProvincia(e.target.value); setMunicipio(''); }} required className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              <option value="">Selecionar</option>
              {PROVINCIAS.map(p => <option key={p.id} value={p.nome}>{p.nome}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Município *</Label>
            <select value={municipio} onChange={e => setMunicipio(e.target.value)} required className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              <option value="">Selecionar</option>
              {municipiosFiltrados.map(m => <option key={m.id} value={m.nome}>{m.nome}</option>)}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input type="checkbox" checked={disponivel} onChange={e => setDisponivel(e.target.checked)} className="accent-primary" id="disponivel" />
          <Label htmlFor="disponivel" className="font-corpo text-sm">Disponível para venda</Label>
        </div>

        <Button type="submit" className="w-full font-corpo font-semibold">
          <PlusCircle className="w-4 h-4 mr-2" />
          Publicar Produto
        </Button>
      </form>
    </div>
  );
}
