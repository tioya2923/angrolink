/**
 * Vendedor — Perfil da empresa (com foto de perfil)
 */

import { useState } from 'react';
import { Save, ShieldCheck, Camera } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { obterVendedorPorId } from '@/dados/mock';
import { TIPOS_VENDEDOR, PROVINCIAS, MUNICIPIOS } from '@/dados/constantes';
import { useToast } from '@/hooks/use-toast';

export default function VendedorPerfil() {
  const { utilizador } = useAuth();
  const { toast } = useToast();
  const vendedor = obterVendedorPorId(utilizador?.vendedor_id || '');

  const [nomeComercial, setNomeComercial] = useState(vendedor?.nome_comercial || '');
  const [descricao, setDescricao] = useState(vendedor?.descricao || '');
  const [tipoVendedor, setTipoVendedor] = useState(vendedor?.tipo_vendedor || '');
  const [provincia, setProvincia] = useState(vendedor?.provincia || '');
  const [municipio, setMunicipio] = useState(vendedor?.municipio || '');
  const [mercado, setMercado] = useState(vendedor?.mercado_bairro || '');
  const [fotoPreview, setFotoPreview] = useState<string | null>(null);

  const municipiosFiltrados = MUNICIPIOS.filter(
    m => m.provincia_id === PROVINCIAS.find(p => p.nome === provincia)?.id
  );

  const handleFotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast({ title: 'Imagem demasiado grande', description: 'Tamanho máximo: 500KB', variant: 'destructive' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setFotoPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleGuardar = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: 'Perfil atualizado!' });
  };

  return (
    <div className="space-y-6 max-w-lg">
      <h1 className="font-titulo text-2xl font-bold">Perfil da Empresa</h1>

      {/* Foto de perfil */}
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="w-20 h-20 rounded-full border-2 border-border overflow-hidden bg-muted flex items-center justify-center">
            {fotoPreview ? (
              <img src={fotoPreview} alt="Foto de perfil" className="w-full h-full object-cover" />
            ) : (
              <Camera size={24} className="text-muted-foreground" />
            )}
          </div>
          <label className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
            <Camera size={12} />
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleFotoChange} className="hidden" />
          </label>
        </div>
        <div>
          <p className="font-corpo text-sm font-medium">Foto de perfil</p>
          <p className="font-corpo text-xs text-muted-foreground">Máximo 500KB · JPG, PNG</p>
        </div>
      </div>

      {/* Estado da conta */}
      <div className="border-2 border-border p-4">
        <div className="flex items-center gap-2">
          <ShieldCheck size={18} className={vendedor?.verificado ? 'text-primary' : 'text-muted-foreground'} />
          <span className="font-corpo text-sm">
            {vendedor?.verificado ? 'Conta Verificada' : 'Conta Não Verificada'}
          </span>
        </div>
        <p className="font-corpo text-xs text-muted-foreground mt-1">
          Plano: <strong>{vendedor?.plano || 'gratuito'}</strong>
        </p>
      </div>

      <form onSubmit={handleGuardar} className="space-y-4">
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Nome do negócio</Label>
          <Input value={nomeComercial} onChange={e => setNomeComercial(e.target.value)} className="border-2 border-border" />
        </div>
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Descrição</Label>
          <textarea
            value={descricao}
            onChange={e => setDescricao(e.target.value)}
            rows={3}
            className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary resize-none"
          />
        </div>
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Tipo de vendedor</Label>
          <select value={tipoVendedor} onChange={e => setTipoVendedor(e.target.value)} className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
            {TIPOS_VENDEDOR.map(t => <option key={t.valor} value={t.valor}>{t.rotulo}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Província</Label>
            <select value={provincia} onChange={e => { setProvincia(e.target.value); setMunicipio(''); }} className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              <option value="">Selecionar</option>
              {PROVINCIAS.map(p => <option key={p.id} value={p.nome}>{p.nome}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Município</Label>
            <select value={municipio} onChange={e => setMunicipio(e.target.value)} className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary">
              <option value="">Selecionar</option>
              {municipiosFiltrados.map(m => <option key={m.id} value={m.nome}>{m.nome}</option>)}
            </select>
          </div>
        </div>
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Mercado / Bairro</Label>
          <Input value={mercado} onChange={e => setMercado(e.target.value)} className="border-2 border-border" />
        </div>

        <Button type="submit" className="font-corpo font-semibold">
          <Save className="w-4 h-4 mr-2" /> Guardar Perfil
        </Button>
      </form>
    </div>
  );
}
