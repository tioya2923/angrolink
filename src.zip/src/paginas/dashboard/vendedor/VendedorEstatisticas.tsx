/**
 * Vendedor — Estatísticas simples
 */

import { BarChart3, Eye, MessageSquare, TrendingUp } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { PRODUTOS_MOCK } from '@/dados/mock';
import { STATS_VENDEDOR_MOCK } from '@/dados/mockDashboard';

export default function VendedorEstatisticas() {
  const { utilizador } = useAuth();
  const meusProdutos = PRODUTOS_MOCK.filter(p => p.vendedor_id === utilizador?.vendedor_id);

  /* Mock: gerar visualizações aleatórias para os produtos */
  const produtosComStats = meusProdutos.map(p => ({
    ...p,
    visualizacoes: p.visualizacoes || Math.floor(Math.random() * 150) + 10,
    cliques_whatsapp: p.cliques_whatsapp || Math.floor(Math.random() * 30) + 1,
  })).sort((a, b) => b.visualizacoes - a.visualizacoes);

  return (
    <div className="space-y-6">
      <h1 className="font-titulo text-2xl font-bold">Estatísticas</h1>

      {/* Resumo geral */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <div className="border-2 border-border p-4">
          <Eye size={20} className="text-primary mb-2" />
          <p className="font-titulo text-2xl">{STATS_VENDEDOR_MOCK.visualizacoes}</p>
          <p className="font-corpo text-xs text-muted-foreground">Visualizações totais</p>
        </div>
        <div className="border-2 border-border p-4">
          <MessageSquare size={20} className="text-primary mb-2" />
          <p className="font-titulo text-2xl">{STATS_VENDEDOR_MOCK.cliquesWhatsapp}</p>
          <p className="font-corpo text-xs text-muted-foreground">Cliques WhatsApp</p>
        </div>
        <div className="border-2 border-border p-4">
          <TrendingUp size={20} className="text-primary mb-2" />
          <p className="font-titulo text-2xl">{STATS_VENDEDOR_MOCK.perfilVisto}</p>
          <p className="font-corpo text-xs text-muted-foreground">Perfil visto esta semana</p>
        </div>
      </div>

      {/* Produtos mais vistos — barras simples */}
      <div className="border-2 border-border p-4">
        <h3 className="font-titulo text-sm mb-4">Produtos Mais Vistos</h3>
        <div className="space-y-3">
          {produtosComStats.map(p => {
            const maxViews = produtosComStats[0]?.visualizacoes || 1;
            const pct = (p.visualizacoes / maxViews) * 100;
            return (
              <div key={p.id} className="space-y-1">
                <div className="flex justify-between">
                  <span className="font-corpo text-xs">{p.nome_produto}</span>
                  <span className="font-corpo text-xs text-muted-foreground">{p.visualizacoes} views</span>
                </div>
                <div className="h-2 bg-muted">
                  <div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Produtos com mais contactos */}
      <div className="border-2 border-border p-4">
        <h3 className="font-titulo text-sm mb-4">Produtos com Mais Contactos</h3>
        <div className="space-y-3">
          {produtosComStats.sort((a, b) => b.cliques_whatsapp - a.cliques_whatsapp).map(p => {
            const maxClicks = produtosComStats[0]?.cliques_whatsapp || 1;
            const pct = (p.cliques_whatsapp / maxClicks) * 100;
            return (
              <div key={p.id} className="space-y-1">
                <div className="flex justify-between">
                  <span className="font-corpo text-xs">{p.nome_produto}</span>
                  <span className="font-corpo text-xs text-muted-foreground">{p.cliques_whatsapp} contactos</span>
                </div>
                <div className="h-2 bg-muted">
                  <div className="h-full bg-secondary transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
