/**
 * Vendedor — Dashboard resumo
 */

import { Package, Eye, MessageSquare, Star, UserCircle } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { STATS_VENDEDOR_MOCK } from '@/dados/mockDashboard';

export default function VendedorResumo() {
  const { utilizador } = useAuth();
  const stats = STATS_VENDEDOR_MOCK;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-titulo text-2xl font-bold">
          Bem-vindo, {utilizador?.nome}
        </h1>
        <p className="font-corpo text-sm text-muted-foreground mt-1">
          Gerencie os seus produtos e acompanhe o interesse
        </p>
      </div>

      {/* Alerta motivacional */}
      <div className="border-2 border-primary bg-primary/5 p-4">
        <p className="font-corpo text-sm text-primary">
          <UserCircle size={16} className="inline mr-1" />
          Seu perfil foi visto <strong>{stats.perfilVisto}</strong> vezes esta semana
        </p>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        <CardStat icone={Package} rotulo="Produtos Ativos" valor={stats.produtosAtivos} />
        <CardStat icone={Package} rotulo="Total Produtos" valor={stats.totalProdutos} />
        <CardStat icone={Eye} rotulo="Visualizações" valor={stats.visualizacoes} />
        <CardStat icone={MessageSquare} rotulo="Contactos" valor={stats.cliquesWhatsapp} />
        <CardStat icone={Star} rotulo="Destacados" valor={stats.produtosDestacados} />
      </div>
    </div>
  );
}

function CardStat({ icone: Icone, rotulo, valor }: { icone: React.ComponentType<any>; rotulo: string; valor: number }) {
  return (
    <div className="border-2 border-border p-4">
      <Icone size={20} className="text-primary mb-2" />
      <p className="font-titulo text-2xl">{valor}</p>
      <p className="font-corpo text-xs text-muted-foreground">{rotulo}</p>
    </div>
  );
}
