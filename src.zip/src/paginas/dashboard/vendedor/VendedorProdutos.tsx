/**
 * Vendedor — Lista dos seus produtos
 */

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Star, Edit, Trash2, Share2, Eye } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { PRODUTOS_MOCK } from '@/dados/mock';
import { Produto } from '@/tipos';
import { useToast } from '@/hooks/use-toast';

export default function VendedorProdutos() {
  const { utilizador } = useAuth();
  const { toast } = useToast();

  const [produtos, setProdutos] = useState<Produto[]>(
    PRODUTOS_MOCK.filter(p => p.vendedor_id === utilizador?.vendedor_id)
  );

  const removerProduto = (id: string) => {
    setProdutos(prev => prev.filter(p => p.id !== id));
    toast({ title: 'Produto removido' });
  };

  const toggleDestaque = (id: string) => {
    setProdutos(prev => prev.map(p => p.id === id ? { ...p, destaque: !p.destaque } : p));
    toast({ title: 'Destaque atualizado' });
  };

  /** Copiar link do produto para partilhar */
  const partilharProduto = (p: Produto) => {
    const url = `${window.location.origin}/produto/${p.id}`;
    navigator.clipboard.writeText(url);
    toast({ title: 'Link copiado!', description: 'Partilha no WhatsApp, Facebook ou grupos.' });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-titulo text-2xl font-bold">Meus Produtos</h1>
        <Link
          to="/dashboard/adicionar"
          className="flex items-center gap-2 font-corpo text-sm bg-primary text-primary-foreground px-4 py-2 hover:bg-primary/90 transition-colors"
        >
          <PlusCircle size={16} />
          Adicionar Produto
        </Link>
      </div>

      {produtos.length === 0 ? (
        <p className="font-corpo text-sm text-muted-foreground">Ainda não publicaste nenhum produto.</p>
      ) : (
        <div className="space-y-3">
          {produtos.map(p => (
            <div key={p.id} className="border-2 border-border p-3 flex flex-col sm:flex-row gap-3">
              <div className="w-full sm:w-24 h-20 bg-muted shrink-0">
                <img src={p.imagem_principal} alt={p.nome_produto} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-titulo text-sm">{p.nome_produto}</span>
                  {p.destaque && <Star size={14} className="text-secondary fill-secondary" />}
                </div>
                <p className="font-corpo text-xs text-muted-foreground">
                  {p.preco_aproximado.toLocaleString()} Kz/{p.unidade} · {p.categoria} · {p.disponivel ? 'Disponível' : 'Indisponível'}
                </p>
                <p className="font-corpo text-xs text-muted-foreground flex items-center gap-1">
                  <Eye size={12} /> {p.visualizacoes || Math.floor(Math.random() * 100)} visualizações
                </p>
              </div>
              <div className="flex sm:flex-col gap-2 shrink-0">
                <button onClick={() => toast({ title: 'Edição disponível com backend' })} className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-primary hover:text-primary transition-colors">
                  <Edit size={12} className="inline mr-1" />Editar
                </button>
                <button onClick={() => toggleDestaque(p.id)} className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-secondary hover:text-secondary transition-colors">
                  <Star size={12} className="inline mr-1" />{p.destaque ? 'Remover' : 'Destacar'}
                </button>
                <button onClick={() => partilharProduto(p)} className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-primary hover:text-primary transition-colors">
                  <Share2 size={12} className="inline mr-1" />Partilhar
                </button>
                <button onClick={() => removerProduto(p.id)} className="font-corpo text-xs border-2 border-border px-3 py-1.5 hover:border-destructive hover:text-destructive transition-colors">
                  <Trash2 size={12} className="inline mr-1" />Remover
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
