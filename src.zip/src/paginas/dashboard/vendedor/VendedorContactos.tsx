/**
 * Vendedor — Contactos recebidos via WhatsApp
 */

import { MessageSquare, Phone } from 'lucide-react';
import { CONTACTOS_VENDEDOR_MOCK } from '@/dados/mockDashboard';

export default function VendedorContactos() {
  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Contactos Recebidos</h1>
      <p className="font-corpo text-sm text-muted-foreground">
        Pessoas que clicaram no WhatsApp para consultar os teus produtos.
      </p>

      {CONTACTOS_VENDEDOR_MOCK.length === 0 ? (
        <p className="font-corpo text-sm text-muted-foreground">Ainda não recebeste contactos.</p>
      ) : (
        <div className="space-y-2">
          {CONTACTOS_VENDEDOR_MOCK.map(c => (
            <div key={c.id} className="border-2 border-border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <p className="font-titulo text-sm">{c.nome_produto}</p>
                <p className="font-corpo text-xs text-muted-foreground">
                  <Phone size={12} className="inline mr-1" />
                  {c.telefone_cliente} · {c.data}
                </p>
              </div>
              <a
                href={`https://wa.me/${c.telefone_cliente.replace(/\s+/g, '').replace('+', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 font-corpo text-xs border-2 border-primary text-primary px-3 py-1.5 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <MessageSquare size={14} />
                Responder
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
