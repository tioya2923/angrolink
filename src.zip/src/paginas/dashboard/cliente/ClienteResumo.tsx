/**
 * Cliente — Resumo do dashboard
 */

import { Eye, Phone, Heart } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { STATS_CLIENTE_MOCK } from '@/dados/mockDashboard';

export default function ClienteResumo() {
  const { utilizador } = useAuth();
  const stats = STATS_CLIENTE_MOCK;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-titulo text-2xl font-bold">
          Bem-vindo, {utilizador?.nome}
        </h1>
        <p className="font-corpo text-sm text-muted-foreground mt-1">
          Acompanhe os seus produtos e vendedores favoritos
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <CardStat icone={Eye} rotulo="Produtos Visualizados" valor={stats.produtosVisualizados} />
        <CardStat icone={Phone} rotulo="Vendedores Contactados" valor={stats.vendedoresContactados} />
        <CardStat icone={Heart} rotulo="Produtos Guardados" valor={stats.produtosGuardados} />
      </div>
    </div>
  );
}

function CardStat({ icone: Icone, rotulo, valor }: { icone: React.ComponentType<any>; rotulo: string; valor: number }) {
  return (
    <div className="border-2 border-border p-4">
      <Icone size={20} className="text-primary mb-2" />
      <p className="font-titulo text-2xl">{valor}</p>
      <p className="font-corpo text-xs text-muted-foreground">{rotulo}</p>
    </div>
  );
}
