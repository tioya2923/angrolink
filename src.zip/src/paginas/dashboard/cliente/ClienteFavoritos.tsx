/**
 * Cliente — Produtos e vendedores favoritos
 */

import { Heart, MessageSquare } from 'lucide-react';
import { PRODUTOS_MOCK, obterVendedorPorId, gerarLinkWhatsApp } from '@/dados/mock';
import { FAVORITOS_CLIENTE_MOCK } from '@/dados/mockDashboard';

export default function ClienteFavoritos() {
  const favoritos = PRODUTOS_MOCK.filter(p => FAVORITOS_CLIENTE_MOCK.includes(p.id));

  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Meus Favoritos</h1>

      {favoritos.length === 0 ? (
        <p className="font-corpo text-sm text-muted-foreground">Ainda não guardaste nenhum produto.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {favoritos.map(p => {
            const vendedor = obterVendedorPorId(p.vendedor_id);
            return (
              <div key={p.id} className="border-2 border-border overflow-hidden">
                <div className="h-32 bg-muted flex items-center justify-center">
                  <img src={p.imagem_principal} alt={p.nome_produto} className="h-full w-full object-cover" />
                </div>
                <div className="p-3 space-y-2">
                  <h3 className="font-titulo text-sm">{p.nome_produto}</h3>
                  <p className="font-corpo text-xs text-muted-foreground">
                    {p.preco_aproximado.toLocaleString()} Kz/{p.unidade} · {p.municipio}
                  </p>
                  {vendedor && (
                    <a
                      href={gerarLinkWhatsApp(vendedor.telefone_whatsapp, p.nome_produto)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 font-corpo text-xs text-primary hover:underline"
                    >
                      <MessageSquare size={14} />
                      Contactar no WhatsApp
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
