/**
 * Cliente — Histórico de contactos com vendedores
 */

import { MessageSquare } from 'lucide-react';
import { HISTORICO_CLIENTE_MOCK } from '@/dados/mockDashboard';
import { obterVendedorPorId, gerarLinkWhatsApp } from '@/dados/mock';

export default function ClienteHistorico() {
  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Histórico de Contactos</h1>

      {HISTORICO_CLIENTE_MOCK.length === 0 ? (
        <p className="font-corpo text-sm text-muted-foreground">Ainda não contactaste nenhum vendedor.</p>
      ) : (
        <div className="space-y-2">
          {HISTORICO_CLIENTE_MOCK.map(h => {
            const vendedor = obterVendedorPorId(h.vendedor_id);
            return (
              <div key={h.id} className="border-2 border-border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <p className="font-titulo text-sm">{h.nome_vendedor}</p>
                  <p className="font-corpo text-xs text-muted-foreground">
                    Produto: {h.nome_produto} · {h.data}
                  </p>
                </div>
                {vendedor && (
                  <a
                    href={gerarLinkWhatsApp(vendedor.telefone_whatsapp, h.nome_produto)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 font-corpo text-xs border-2 border-primary text-primary px-3 py-1.5 hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <MessageSquare size={14} />
                    Abrir WhatsApp
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
