/**
 * Cliente — Definições da conta (com foto de perfil)
 */

import { useState } from 'react';
import { Save, Trash2, Lock, Camera } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { PROVINCIAS, MUNICIPIOS } from '@/dados/constantes';
import { useToast } from '@/hooks/use-toast';

export default function ClienteDefinicoes() {
  const { utilizador } = useAuth();
  const { toast } = useToast();

  const [nome, setNome] = useState(utilizador?.nome || '');
  const [telefone, setTelefone] = useState(utilizador?.telefone || '');
  const [email, setEmail] = useState(utilizador?.email || '');
  const [provincia, setProvincia] = useState(utilizador?.provincia || '');
  const [municipio, setMunicipio] = useState(utilizador?.municipio || '');
  const [fotoPreview, setFotoPreview] = useState<string | null>(null);

  const municipiosFiltrados = MUNICIPIOS.filter(
    m => m.provincia_id === PROVINCIAS.find(p => p.nome === provincia)?.id
  );

  const handleFotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast({ title: 'Imagem demasiado grande', description: 'Tamanho máximo: 500KB', variant: 'destructive' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setFotoPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleGuardar = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: 'Definições guardadas!' });
  };

  return (
    <div className="space-y-6 max-w-lg">
      <h1 className="font-titulo text-2xl font-bold">Definições da Conta</h1>

      {/* Foto de perfil */}
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="w-20 h-20 rounded-full border-2 border-border overflow-hidden bg-muted flex items-center justify-center">
            {fotoPreview ? (
              <img src={fotoPreview} alt="Foto de perfil" className="w-full h-full object-cover" />
            ) : (
              <Camera size={24} className="text-muted-foreground" />
            )}
          </div>
          <label className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
            <Camera size={12} />
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleFotoChange} className="hidden" />
          </label>
        </div>
        <div>
          <p className="font-corpo text-sm font-medium">Foto de perfil</p>
          <p className="font-corpo text-xs text-muted-foreground">Máximo 500KB · JPG, PNG</p>
        </div>
      </div>

      <form onSubmit={handleGuardar} className="space-y-4">
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Nome</Label>
          <Input value={nome} onChange={e => setNome(e.target.value)} className="border-2 border-border" />
        </div>
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Telefone</Label>
          <Input value={telefone} onChange={e => setTelefone(e.target.value)} className="border-2 border-border" />
        </div>
        <div className="space-y-2">
          <Label className="font-corpo text-sm">Email</Label>
          <Input value={email} onChange={e => setEmail(e.target.value)} type="email" className="border-2 border-border" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Província</Label>
            <select
              value={provincia}
              onChange={e => { setProvincia(e.target.value); setMunicipio(''); }}
              className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary"
            >
              <option value="">Selecionar</option>
              {PROVINCIAS.map(p => <option key={p.id} value={p.nome}>{p.nome}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="font-corpo text-sm">Município</Label>
            <select
              value={municipio}
              onChange={e => setMunicipio(e.target.value)}
              className="w-full border-2 border-border bg-background font-corpo text-sm px-3 py-2 focus:outline-none focus:border-primary"
            >
              <option value="">Selecionar</option>
              {municipiosFiltrados.map(m => <option key={m.id} value={m.nome}>{m.nome}</option>)}
            </select>
          </div>
        </div>

        <Button type="submit" className="font-corpo font-semibold">
          <Save className="w-4 h-4 mr-2" /> Guardar Alterações
        </Button>
      </form>

      {/* Ações extra */}
      <div className="border-t-2 border-border pt-4 space-y-3">
        <button
          onClick={() => toast({ title: 'Funcionalidade disponível com backend' })}
          className="flex items-center gap-2 font-corpo text-sm text-foreground hover:text-primary transition-colors"
        >
          <Lock size={16} /> Alterar Password
        </button>
        <button
          onClick={() => toast({ title: 'Funcionalidade disponível com backend', variant: 'destructive' })}
          className="flex items-center gap-2 font-corpo text-sm text-destructive hover:underline"
        >
          <Trash2 size={16} /> Apagar Conta
        </button>
      </div>
    </div>
  );
}
