/**
 * Cliente — Produtos recomendados com base na localização
 */

import { MapPin, MessageSquare } from 'lucide-react';
import { useAuth } from '@/contextos/AuthContexto';
import { PRODUTOS_MOCK, obterVendedorPorId, gerarLinkWhatsApp } from '@/dados/mock';

export default function ClienteRecomendacoes() {
  const { utilizador } = useAuth();

  /* Mock: recomendar produtos do mesmo município ou província */
  const recomendados = PRODUTOS_MOCK.filter(
    p => p.disponivel && (p.municipio === utilizador?.municipio || p.provincia === utilizador?.provincia)
  ).slice(0, 6);

  return (
    <div className="space-y-4">
      <h1 className="font-titulo text-2xl font-bold">Recomendações</h1>
      <p className="font-corpo text-sm text-muted-foreground flex items-center gap-1">
        <MapPin size={14} /> Produtos perto de si — {utilizador?.municipio}, {utilizador?.provincia}
      </p>

      {recomendados.length === 0 ? (
        <p className="font-corpo text-sm text-muted-foreground">Sem recomendações disponíveis de momento.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {recomendados.map(p => {
            const vendedor = obterVendedorPorId(p.vendedor_id);
            return (
              <div key={p.id} className="border-2 border-border overflow-hidden">
                <div className="h-32 bg-muted flex items-center justify-center">
                  <img src={p.imagem_principal} alt={p.nome_produto} className="h-full w-full object-cover" />
                </div>
                <div className="p-3 space-y-2">
                  <h3 className="font-titulo text-sm">{p.nome_produto}</h3>
                  <p className="font-corpo text-xs text-muted-foreground">
                    {p.preco_aproximado.toLocaleString()} Kz/{p.unidade} · {p.municipio}
                  </p>
                  {vendedor && (
                    <a
                      href={gerarLinkWhatsApp(vendedor.telefone_whatsapp, p.nome_produto)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 font-corpo text-xs text-primary hover:underline"
                    >
                      <MessageSquare size={14} />
                      Contactar
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
