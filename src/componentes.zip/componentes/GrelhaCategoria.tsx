import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchCategorias, guardarHistoricoPesquisa } from '@/services/api';
import { useAuth } from '@/contextos/AuthContexto';

import {
  Leaf,
  Wheat,
  Beef,
  Wine,
  UtensilsCrossed,
  Package,
  Wrench,
  LucideIcon
} from 'lucide-react';

// Mapa fixo de ícones
const MAPA_ICONES: Record<string, LucideIcon> = {
  alimentos: UtensilsCrossed,
  bebidas: Wine,
  'grãos e cereais': Wheat,
  'pecuária': Beef,
  'produtos frescos': Leaf,
  serviços: Wrench,
};

export default function GrelhaCategoria() {
  const [categorias, setCategorias] = useState<any[]>([]);
  const { utilizador, tipoComprador } = useAuth();

  useEffect(() => {
    async function carregar() {
      const data = await fetchCategorias();
      setCategorias(data || []);
    }

    carregar();
  }, []);

  return (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-3 md:gap-4">
      {categorias.map(cat => {
        const nome = cat.nome.toLowerCase().trim();
        const Icone = MAPA_ICONES[nome] || Package;

        const destino =
          nome === 'serviços'
            ? '/servicos'
            : `/pesquisa?categoria=${cat.id}`;

        return (
          <Link
            key={cat.id}
            to={destino}
            onClick={() => {
              console.log('Clique categoria:', {
                categoria: cat.nome,
                papel: utilizador?.papel,
                utilizador,
              });

              if (nome === 'serviços') return;

              if (utilizador?.papel === 'admin') {
                console.log('Clique ignorado: admin não conta nas métricas.');
                return;
              }

              guardarHistoricoPesquisa({
                cliente_id: utilizador?.papel === 'cliente' ? utilizador.id : null,
                categoria_id: cat.id,
                tipo_comprador: tipoComprador,
              });
            }}
            className="flex flex-col items-center gap-2 p-4 border-2 border-border bg-background hover:border-green-700 transition-colors group"
          >
            <Icone
              size={28}
              className="text-foreground group-hover:text-green-700 transition-colors"
              fill="currentColor"
            />

            <span className="text-xs md:text-sm text-center">
              {cat.nome}
            </span>
          </Link>
        );
      })}
    </div>
  );
}