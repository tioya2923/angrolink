import { Produto, Servico } from '@/tipos';
import CardProduto from './CardProduto';
import CardServico from './CardServico';

type Destaque =
  | {
      tipo: 'produto';
      item: Produto;
    }
  | {
      tipo: 'servico';
      item: Servico;
    };

interface ListaDestaquesProps {
  destaques: Destaque[];
  titulo?: string;
}

export default function ListaDestaques({
  destaques,
  titulo = 'Destaques ANGROLINK',
}: ListaDestaquesProps) {
  const listaSegura = Array.isArray(destaques) ? destaques : [];

  if (listaSegura.length === 0) return null;

  return (
    <section>
      <h2 className="font-titulo text-xl md:text-2xl mb-4 text-white">
        {titulo}
      </h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
        {listaSegura.map(destaque => {
          if (destaque.tipo === 'produto') {
            return (
              <CardProduto
                key={`produto-${destaque.item.id}`}
                produto={destaque.item}
              />
            );
          }

          return (
            <CardServico
              key={`servico-${destaque.item.id}`}
              servico={destaque.item}
            />
          );
        })}
      </div>
    </section>
  );
}